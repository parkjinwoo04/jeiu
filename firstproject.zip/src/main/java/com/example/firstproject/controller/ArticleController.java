package com.example.firstproject.controller;

import com.example.firstproject.dto.ArticleDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller

public class ArticleController {

    @GetMapping("/article/new")
    public String newArticleForm(){
        return "articles/new";
    }

    @PostMapping("/article/create")
    public String newArticleForm(ArticleDTO dto){
        System.out.println("제목: " + dto.getTitle());
        System.out.println("내용: " + dto.getContent());
        return "";
    }

}
