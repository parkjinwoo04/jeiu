package com.example.firstproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FirstController {
    @GetMapping("/intro")
    public String myIntro(Model mo){
        mo.addAttribute("myName", "박진우");
        return "myIntroView";
    }

    @GetMapping("/hi")
    String hello(){
        return "helloTempView";
    }

    @GetMapping("/")
    String home(){
        return "index";
    }

    @GetMapping("/login")
    String login(){
        return "login";

    }

}
