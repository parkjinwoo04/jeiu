import streamlit as st
from streamlit.components.v1 import html
from streamlit_js_eval import streamlit_js_eval, get_user_agent, get_geolocation
from audio_recorder_streamlit import audio_recorder
import json
import time, datetime
import pandas as pd
import numpy as np
import random
from utils.time_and_locations import reverse_geocode, get_geocode
from utils.clova_speech import get_clova_stt

# 💡 카카오 API 모듈과 OpenAI 기능 로드
from utils.openai_agent import get_search_query, get_order_type, get_review
from utils.kakao_search import get_place_info  # 👈 카카오로 변경된 부분

st.set_page_config(layout="wide")

def main():
    """ NLP Based App with Streamlit (카카오 맵 통합 버전) """

    # 1. Session State 초기화 (페이지 재실행 시 데이터 유지 및 중복 API 호출 방지)
    if "search_result" not in st.session_state:
        st.session_state.search_result = pd.DataFrame()
    if "final_candidates" not in st.session_state:
        st.session_state.final_candidates = False
    if "review_summaries" not in st.session_state:
        st.session_state.review_summaries = {}

    # 현재 날짜 및 시간대 계산
    KST = datetime.timezone(datetime.timedelta(hours=9))
    timestamp = datetime.datetime.fromtimestamp(time.time(), tz=KST)
    year, month, day = str(timestamp).split()[0].split(sep='-')
    cur_time = int(str(timestamp).split()[1].split(":")[0])
    if cur_time < 11:
         cur_time = "아침"
    elif cur_time < 17:
         cur_time = "점심"
    else:
         cur_time = "저녁"
    weekday = ["월", "화", "수", "목", "금", "토", "일"][timestamp.weekday()]

    # 현재 위치 출력
    try:
        loc = get_geolocation()
        latitude = loc['coords']['latitude']
        longitude = loc['coords']['longitude']
        geocode = f"{longitude},{latitude}"
        admcode = reverse_geocode(geocode)
    except:
        admcode = ("서울시", "성동구", "성수동")
    
    # 상단 기본 정보 UI
    st.title("LLM 기반 맛집 추천 (카카오 맵 통합 버전)")
    st.text_input("**현재 날짜**", f"{year}년 {month}월 {day}일 ({weekday}요일)", disabled=True)
    st.markdown(f"**현재 시간:** {cur_time}")
    cur_loc = st.text_input("**현재 위치**", f"{admcode[1]}")

    sample_input = "한양대 점심 먹을 곳 추천해주세요"
    parsed_cmd = None
    
    debug = st.checkbox("중간 과정 표시", value=False)

    # 2. 명령 입력 섹션 (텍스트 / 음성)
    with st.expander("명령 입력", expanded=True):
        input_type = st.selectbox("입력 방식", options=["텍스트", "음성"])
        
        if input_type == "음성":
            col1, col2 = st.columns([1, 3])
            with col1:
                audio_bytes = audio_recorder(
                    text="요청사항 입력",
                    recording_color="#e8b62c",
                    neutral_color="#6aa36f",
                    icon_name="microphone",
                    icon_size="6x",
                )
            if audio_bytes:
                with st.spinner("음성 인식 중..."):
                    query = get_clova_stt(audio_bytes).get("text", None)
                if query:
                    col2.subheader(query)
                    parsed_cmd = {"loc": cur_loc, "pref": query, "time": cur_time}
        
        elif input_type == "텍스트":
            query = st.text_input("요청사항 입력", sample_input)
            if st.button("맛집 탐색 시작!", type='primary'):
                with st.spinner("요청사항 분석중"):
                    parsed_cmd = {"loc": cur_loc, "pref": query, "time": cur_time}
                    for time_keyword in ["아침", "점심", "저녁"]:
                        if time_keyword in query:
                            parsed_cmd["time"] = time_keyword

    spinner_loc = st.empty()
    
    # 3. 데이터 파이프라인 및 백엔드 연동 (새로운 검색 요청 유입 시에만 실행)
    if parsed_cmd is not None:
        # 새로운 검색 요청이 들어왔으므로 기존 캐시 초기화
        st.session_state.final_candidates = False
        st.session_state.review_summaries = {}
        
        if parsed_cmd['time'] == "없음":
            parsed_cmd['time'] = cur_time
        if parsed_cmd['loc'] == "없음":
            parsed_cmd["loc"] = cur_loc
            
        with st.expander("검색 과정", expanded=debug):        
            st.subheader("입력 요청 분석 결과")
            st.write(parsed_cmd)
            
            with spinner_loc:
                with st.spinner("검색 방식 및 검색어 생성중"):
                    search_query = get_search_query(loc=parsed_cmd['loc'], pref=parsed_cmd['pref'])
            st.subheader("요청사항 기반 검색어")
            st.write(search_query)
            
            search_result = pd.DataFrame()
            
            with spinner_loc:
                with st.spinner("카카오 맵에서 맛집 검색중"):
                    for _query in search_query.get("query", []):
                        try:
                            res = get_place_info(_query)
                            if res is not None and not res.empty:
                                search_result = pd.concat((search_result, res))
                        except Exception as e:
                            continue
            
            if not search_result.empty:
                # 중복된 식당 이름 정리
                if "clean_title" in search_result.columns:
                    search_result = search_result.drop_duplicates(subset=["clean_title"]).reset_index(drop=True)
                    
                    st.subheader("카카오 맵 최초 검색 결과")
                    st.write(search_result)

                    # 카테고리 필터링 분석 단계
                    with spinner_loc:
                        with st.spinner("부적절한 메뉴 파악 및 제거중"):
                            menu_analysis = get_order_type(instruction=query)
                    menu_type = menu_analysis.get("type", "")
                    target_to_remove = menu_analysis.get("targets", [])

                    st.subheader("입력 기반 카테고리 정제 결과")
                    st.markdown(f"**명령 타입:** {menu_type}")
                    st.markdown(f"**제거 대상:** {target_to_remove}")

                    # 카테고리 필터링 적용
                    if "category" in search_result.columns and target_to_remove:
                        filtered_idx = []
                        for cat in search_result["category"]:
                            is_target = False
                            for target in target_to_remove:
                                if target in str(cat):
                                    is_target = True
                                    break
                            filtered_idx.append(not is_target)
                        search_result = search_result[filtered_idx]

                    st.subheader("카테고리 정제 완결 결과")
                    st.write(search_result)

                    # 최대 3개의 최종 후보 무작위 추출
                    sample_size = min(len(search_result), 3)
                    if sample_size > 0:
                        search_result = search_result.sample(n=sample_size).reset_index(drop=True)
                        st.subheader("최종 엄선된 후보 맛집")
                        st.write(search_result)
                        
                        # Session state에 데이터 영구 고정
                        st.session_state.search_result = search_result
                        st.session_state.final_candidates = True
            else:
                with spinner_loc:
                    st.warning("카카오 검색 결과를 찾을 수 없습니다. API 설정을 확인하거나 다시 시도해 보세요.")

    # 4. 화면에 최종 맛집 카드 UI 뿌려주기
    if st.session_state.final_candidates and not st.session_state.search_result.empty:
        result_df = st.session_state.search_result
        columns = st.columns(len(result_df.index))
        
        for i, col in enumerate(columns):
            row = result_df.iloc[i]
            title = row['clean_title']
            address = row['address'] if 'address' in row else (row['roadAddress'] if 'roadAddress' in row else '주소 정보 없음')
            category = row['category'] if 'category' in row else '음식점'
            link = row['link'] if 'link' in row and row['link'] else f"https://map.kakao.com/?q={title}"
            description = row['description'] if 'description' in row and str(row['description']) != 'nan' else f"{title}은(는) 해당 지역 인기 매장입니다. 카카오맵 링크에서 상세 리뷰를 확인해 보세요."

            with col:
                st.subheader(f"후보 {i+1}번: {title}")
                st.markdown(f'[👉 카카오 맵 바로가기]({link})')

                # 🗺️ 카카오 맵 좌표 기반의 지도 보기 구현
                with st.expander(f"[🗺️ 지도 보기] {address}", expanded=False):
                    try:
                        # 1차 시도: 주소 텍스트 기반 지오코딩 변환
                        x, y = get_geocode(address)
                        df_geocode = pd.DataFrame([[float(y), float(x)]], columns=['lat', 'lon'])
                        st.map(df_geocode)
                    except:
                        # 2차 시도: 실패 시 카카오 로컬 API가 준 순수 x, y 좌표 바로 활용
                        # 카카오의 x, y는 이미 완벽한 소수점 문자열 형태('127.04...', '37.55...')이므로 나누기 연산 불필요
                        if 'mapx' in row and 'mapy' in row and row['mapx'] and row['mapy']:
                            try:
                                nx = float(row['mapx'])
                                ny = float(row['mapy'])
                                df_geocode = pd.DataFrame([[ny, nx]], columns=['lat', 'lon'])
                                st.map(df_geocode)
                            except:
                                st.write("📍 지도 로드 실패 - 주소 정보를 참조해 주세요.")
                        else:
                            # 최종 방어선 (서울시청)
                            df_geocode = pd.DataFrame([[37.5665, 126.9780]], columns=['lat', 'lon'])
                            st.map(df_geocode)
                            st.caption("※ 정확한 위치는 상단의 '카카오 맵 바로가기' 링크를 클릭해 주세요.")

                # 상세 스펙 테이블/텍스트 디자인
                st.markdown(f"""
- **카테고리:** {category}
- **위치/주소:** {address}
- **식당 설명:** {description}
                """)

                # OpenAI 요약 처리 (기존에 빌드된 요약본이 없으면 최초 1회 생성 후 박제)
                if title not in st.session_state.review_summaries:
                    with st.spinner(f"{title} AI 분석 요약중"):
                        summary_text = get_review(f"식당명: {title}, 업종: {category}, 설명: {description}, 주소: {address}")
                        st.session_state.review_summaries[title] = summary_text

                # 요약 결과 노출
                with st.expander("🤖 AI 추천 요약 및 특징", expanded=True):
                    st.markdown(st.session_state.review_summaries[title])
            
if __name__ == '__main__':
    main()