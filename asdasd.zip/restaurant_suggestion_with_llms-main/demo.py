import streamlit as st
from streamlit.components.v1 import html
from streamlit_js_eval import streamlit_js_eval, get_user_agent, get_geolocation
from audio_recorder_streamlit import audio_recorder
import json
import time, datetime
import pandas as pd
import numpy as np
import random
from utils.time_and_locations import reverse_geocode, get_geocode
from utils.clova_speech import get_clova_stt

# 💡 고장난 망고플레이트 크롤러를 지우고, 네이버와 OpenAI 기능만 남깁니다.
from utils.openai_agent import get_search_query, get_order_type, get_review
from utils.naver_search import get_place_info

st.set_page_config(layout="wide")


def main():
    """ NLP Based App with Streamlit (네이버 전용 버전) """

    # 현재 날짜 계산
    KST = datetime.timezone(datetime.timedelta(hours=9))
    timestamp = datetime.datetime.fromtimestamp(time.time(), tz=KST)
    year, month, day = str(timestamp).split()[0].split(sep='-')
    cur_time = int(str(timestamp).split()[1].split(":")[0])
    if cur_time < 11:
         cur_time = "아침"
    elif cur_time < 17:
         cur_time = "점심"
    else:
         cur_time = "저녁"
    weekday = ["월", "화", "수", "목", "금", "토", "일"][timestamp.weekday()]

    # 현재 위치 출력
    try:
        loc = get_geolocation()
        latitude = loc['coords']['latitude']
        longitude = loc['coords']['longitude']
        geocode = f"{longitude},{latitude}"
        admcode = reverse_geocode(geocode)
    except:
        admcode = "서울시", "성동구", "성수동"
    
    # Title
    st.title("LLM 기반 맛집 추천 (네이버 지도 통합 버전)")
    st.text_input(f"**현재 날짜**", f"{year}년 {month}월 {day}일 ({weekday}요일)")
    st.markdown(f"**현재 시간:** {cur_time}")
    cur_loc = st.text_input(f"**현재 위치**", f"{admcode[1]}")

    sample_input = "한양대 점심 먹을 곳 추천해주세요"
    parsed_cmd = None
    
    debug = st.checkbox("중간 과정 표시", value=False)

    with st.expander("명령 입력", expanded=True):
        input_type = st.selectbox("입력 방식", options=["텍스트", "음성"])
        if input_type == "음성":
            col1, col2 = st.columns([1, 3])
            with col1:
                audio_bytes = audio_recorder(
                    text="요청사항 입력",
                    recording_color="#e8b62c",
                    neutral_color="#6aa36f",
                    icon_name="microphone",
                    icon_size="6x",
                )
            if audio_bytes:
                query = get_clova_stt(audio_bytes)["text"]
                if query is not None:
                    col2.subheader(query)
                    parsed_cmd = {"loc": cur_loc, "pref": query, "time": cur_time}
        
        elif input_type == "텍스트":
            query = st.text_input("요청사항 입력", sample_input)
            if st.button("맛집 탐색 시작!", type='primary'):
                with st.spinner("요청사항 분석중"):
                    parsed_cmd = {"loc": cur_loc, "pref": query, "time": cur_time}
                    for time_keword in ["아침", "점심", "저녁"]:
                        if time_keword in query:
                            parsed_cmd["time"] = time_keword

    final_candidates = False
    spinner_loc = st.empty()
    
    with st.expander("검색 과정", expanded=debug):                
        if parsed_cmd is not None:
            if parsed_cmd['time'] == "없음":
                parsed_cmd['time'] = cur_time
            if parsed_cmd['loc'] == "없음":
                parsed_cmd["loc"] = cur_loc
            st.subheader("입력 요청 분석 결과")
            st.write(parsed_cmd)
            
            with spinner_loc:
                with st.spinner("검색 방식 및 검색어 생성중"):
                    search_query = get_search_query(loc=parsed_cmd['loc'], pref=parsed_cmd['pref'])
            st.subheader("요청사항 기반 검색어")
            st.write(search_query)
            
            search_result = pd.DataFrame()
            
            with spinner_loc:
                with st.spinner("네이버 지도에서 맛집 검색중"):
                    for _query in search_query["query"]:
                        try:
                            res = get_place_info(_query)
                            if res is not None and not res.empty:
                                search_result = pd.concat((search_result, res))
                        except Exception as e:
                            continue
            
            if search_result is not None and not search_result.empty:
                # 중복된 식당 이름 제거 및 정리
                target_col = None
                for col in ["title", "name", "place_name"]:
                    if col in search_result.columns:
                        target_col = col
                        break
                
                if target_col is not None:
                    search_result = search_result.drop_duplicates(subset=[target_col]).reset_index(drop=True)
                    
                    # HTML 태그 제거 (네이버 API는 <b>태그를 포함해서 줌)
                    search_result['clean_title'] = search_result[target_col].apply(
                        lambda x: x.replace("<b>", "").replace("</b>", "") if isinstance(x, str) else x
                    )
                    
                    st.subheader("네이버지도 검색 결과")
                    st.write(search_result)

                    # 카테고리 필터링 분석 단계
                    with spinner_loc:
                        with st.spinner("부적절한 메뉴 파악 및 제거중"):
                            menu_analysis = get_order_type(instruction=query)
                    menu_type = menu_analysis["type"]
                    target_to_remove = menu_analysis["targets"]

                    st.subheader("입력 기반 카테고리 정제 결과")
                    st.markdown(f"**명령 타입:** {menu_type}")
                    st.markdown(f"**제거 대상:** {target_to_remove}")

                    # 카테고리 컬럼명 매핑 (category 또는 link, description 등 방어 코드)
                    cat_col = "category" if "category" in search_result.columns else None
                    
                    if cat_col and target_to_remove:
                        filtered_idx = []
                        for cat in search_result[cat_col]:
                            is_target = False
                            for target in target_to_remove:
                                if target in str(cat):
                                    is_target = True
                                    break
                            filtered_idx.append(not is_target)
                        search_result = search_result[filtered_idx]

                    st.subheader("카테고리 정제 결과")
                    st.write(search_result)

                    # 최대 3개의 최종 후보 무작위 추출
                    sample_size = min(len(search_result), 3)
                    if sample_size > 0:
                        search_result = search_result.sample(n=sample_size).reset_index(drop=True)
                        st.subheader("최종 엄선된 후보 맛집")
                        st.write(search_result)
                        final_candidates = True
            else:
                with spinner_loc:
                    st.warning("네이버 검색 결과를 찾을 수 없습니다. API Key 설정을 확인하거나 다른 명령으로 다시 시도해보세요.")

    # 💡 화면에 맛집 카드 뿌려주기 코드 개조
    if final_candidates and not search_result.empty:
        columns = st.columns([1] * len(search_result.index))
        for i, col in enumerate(columns):
            row = search_result.iloc[i]
            title = row['clean_title']
            address = row['address'] if 'address' in row else (row['roadAddress'] if 'roadAddress' in row else '주소 정보 없음')
            category = row['category'] if 'category' in row else '음식점'
            link = row['link'] if 'link' in row and row['link'] else f"https://search.naver.com/search.naver?query={title}"
            description = row['description'] if 'description' in row and row['description'] else "네이버 플레이스 정보를 확인해 보세요."

            col.subheader(f"후보 {i+1}번: {title}")
            col.markdown(f'[👉 네이버 지도 바로가기]({link})')

            # ⬇️ 네이버 자체 좌표 백업 기능이 추가된 안전한 코드로 교체
# ⬇️ 변수명 오류(col -> row)를 수정한 안전한 코드
            with col.expander(f"[🗺️ 지도 보기] {address}", expanded=False):
                try:
                    # 1차 시도: 주소 변환 함수 사용
                    x, y = get_geocode(address)
                    df_geocode = pd.DataFrame([[float(y), float(x)]], columns=['lat', 'lon'])
                    st.map(df_geocode)
                except:
                    # 2차 시도: 변환 실패 시 네이버 API가 준 mapx, mapy 데이터 활용 (row에서 가져옴)
                    if 'mapx' in row and 'mapy' in row and row['mapx'] and row['mapy']:
                        try:
                            nx = float(row['mapx']) / 10000000 if float(row['mapx']) > 1000 else float(row['mapx'])
                            ny = float(row['mapy']) / 10000000 if float(row['mapy']) > 1000 else float(row['mapy'])
                            
                            if not (33 <= ny <= 39 and 124 <= nx <= 132):
                                ny, nx = 37.5665, 126.9780  # 서울시청 좌표
                            
                            df_geocode = pd.DataFrame([[ny, nx]], columns=['lat', 'lon'])
                            st.map(df_geocode)
                        except:
                            st.write("📍 주소 정보만 안내해 드립니다.")
                    else:
                        # 최종 방어선
                        df_geocode = pd.DataFrame([[37.5665, 126.9780]], columns=['lat', 'lon'])
                        st.map(df_geocode)
                        st.caption("※ 정확한 위치는 상단의 '네이버 지도 바로가기' 링크를 클릭해 주세요.")

            # 상세 정보 카드 디자인
            col.markdown(f"""
- **카테고리:** {category}
- **위치/주소:** {address}
- **식당 설명:** {description}
            """)

            # 가상 리뷰 텍스트 기반 OpenAI 요약 생성 (망고플레이트 리뷰 대신 식당 설명/소개 기반으로 요약 수행)
            with col:
                with st.spinner(f"{title} AI 분석 요약중"):
                    review_summary = get_review(f"식당명: {title}, 업종: {category}, 설명: {description}, 주소: {address}")
            
            with col.expander("🤖 AI 추천 요약 및 특징", expanded=True):
                st.markdown(review_summary)
            
if __name__ == '__main__':
    # 💡 셀레니움 크롬 드라이버 선언 부를 완전히 삭제하여 쾌적하게 구동합니다.
    main()