import sys
import requests
import json
import pandas as pd
from urllib import parse

# 네이버 API 인증 정보
client_id = "EwjHFmPY5n9qjYUYAsbP"
client_secret = "RM5hZFNPi2"

headers = {
    "X-Naver-Client-Id": client_id,
    "X-Naver-Client-Secret": client_secret,
}

def get_place_info(query, display=5, sort="random"):
    """네이버 지역 검색 API로 식당 정보 가져오기"""
    url = f"https://openapi.naver.com/v1/search/local.json?query={query}&display={display}&start=1&sort={sort}"
    response = requests.get(url=url, headers=headers)
    if response.status_code == 200:
        return pd.DataFrame(json.loads(response.text)['items'])
    else:
        print(f"Error({response.status_code}): " + response.text)
        return None

def get_restaurant_image(query):
    """네이버 이미지 검색 API로 식당 사진 가져오기"""
    encoded_query = parse.quote(query)
    url = f"https://openapi.naver.com/v1/search/image?query={encoded_query}&display=3&start=1&sort=sim&filter=medium"
    response = requests.get(url=url, headers=headers)
    if response.status_code == 200:
        items = json.loads(response.text).get('items', [])
        # 썸네일 이미지 URL 리스트 반환 (최대 3개)
        return [item['thumbnail'] for item in items if 'thumbnail' in item]
    else:
        return []

if __name__ == '__main__':
    result = get_place_info("한양대 맛집")
    print(result)
