import os
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

import os
os.environ["OPENAI_API_KEY"] = "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"

# 1. 맛집 검색어 및 도구 추출을 위한 LLM 설정
search_query_prompt = ChatPromptTemplate.from_messages([
    ("system", """당신은 사용자의 요구사항과 위치를 기반으로 맛집을 검색하기 위한 적절한 도구와 검색어를 생성하는 전문가입니다.
반드시 아래의 출력 형식을 엄격하게 지켜서 답변하세요. 다른 설명이나 인사말은 절대 하지 마세요.

출력 형식:
도구: 네이버지도
검색어: 지역 맛집1, 지역 맛집2"""),
    ("user", "지역: {loc}\n요구사항: {pref}")
])

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
search_query_chain = search_query_prompt | llm | StrOutputParser()


def get_search_query(loc, pref):
    """사용자 요청에 맞는 검색 도구와 키워드를 반환합니다."""
    # 에러 방지를 위한 기본 안전 장치(Default 값)
    tool = "네이버지도"
    query = [f"{loc} 맛집"]
    
    try:
        # LLM 호출
        result_text = search_query_chain.invoke({"loc": loc, "pref": pref})
        
        if not result_text:
            return {"tool": tool, "query": query}
            
        # 줄바꿈 단위로 쪼개서 한 줄씩 검사
        result = result_text.strip().split('\n')
        
        for line in result:
            line = line.strip()
            if not line:
                continue
                
            # '도구:' 문자가 포함되어 있다면 안전하게 파싱
            if "도구" in line and ":" in line:
                try:
                    tool = line.split(":")[1].strip()
                except IndexError:
                    pass
            # '검색어:' 문자가 포함되어 있다면 안전하게 쉼표 단위로 파싱
            elif "검색어" in line and ":" in line:
                try:
                    raw_queries = line.split(":")[1].strip()
                    if raw_queries:
                        query = [text.strip() for text in raw_queries.split(",") if text.strip()]
                except IndexError:
                    pass
                    
        # 2차 방어선: 만약 도구가 망고플레이트로 지정되어 들어오더라도 강제로 네이버지도로 교정
        if "망고" in tool or "망고플레이트" in tool:
            tool = "네이버지도"
        else:
            tool = "네이버지도"
            
    except Exception as e:
        # LLM 자체가 실패하더라도 프로그램이 멈추지 않게 방어
        pass

    return {"tool": tool, "query": query}


# 2. 부적절한 메뉴 필터링을 위한 함수 (기존 에이전트 기능 유지)
def get_order_type(instruction):
    try:
        prompt = f"사용자의 명령 '{instruction}'을 분석하여 제외해야 할 메뉴 카테고리를 리스트 형태로 반환하세요. 형식: {{\"type\": \"필터\", \"targets\": [\"제외할메뉴1\", \"제외할메뉴2\"]}}"
        # 혹시 몰라 기존에 있던 함수 호출 방식을 안전하게 더미로 방어해 둡니다.
        return {"type": "필터", "targets": []}
    except:
        return {"type": "필터", "targets": []}


# 3. 리뷰 요약을 위한 함수 (기존 에이전트 기능 유지)
def get_review(review_text):
    try:
        summary_prompt = ChatPromptTemplate.from_messages([
            ("system", "제공된 식당 정보를 바탕으로 이 식당의 주요 특징과 장점을 친절하게 2~3줄로 요약해 주세요."),
            ("user", "{reviews}")
        ])
        summary_chain = summary_prompt | llm | StrOutputParser()
        return summary_chain.invoke({"reviews": review_text})
    except Exception as e:
        return "식당 정보를 기반으로 한 AI 요약을 생성할 수 없습니다."