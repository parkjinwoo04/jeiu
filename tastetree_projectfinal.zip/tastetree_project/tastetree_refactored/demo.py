import streamlit as st
from streamlit_js_eval import get_geolocation
import re, time, datetime
from urllib import parse as urlparse

from utils.ai_recommender import generate_candidates
from utils.naver_blog      import analyze_all
from utils.kakao_place     import enrich
from utils.nearby          import get_nearby_restaurants
from utils.kakao_place import reverse_geocode_kakao

st.set_page_config(
    page_title="Tastetree : AI 기반 맛집 탐색기",
    page_icon="🌳",
    layout="wide",
)

# ── CSS ──────────────────────────────────────────────────────
st.markdown("""
<style>
[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
    min-height: 100vh;
}
[data-testid="stHeader"] { background: transparent; }
.tt-card {
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(12px);
    border-radius: 18px;
    padding: 20px 22px 16px 22px;
    margin-bottom: 12px;
    border: 1px solid rgba(255,255,255,0.15);
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
}
.tt-card-title {
    font-size: 1.12rem; font-weight: 700; color: #ffffff; margin-bottom: 4px;
}
.tt-highlight { font-size: 0.85rem; color: #b197fc; font-weight: 600; margin-bottom: 6px; }
.tt-meta { color: #cbd5e1; font-size: 0.87rem; line-height: 1.8; margin-top: 8px; }
.tt-reason {
    background: rgba(99,102,241,0.15);
    border-left: 3px solid #7c3aed;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px; font-size: 0.86rem;
    color: #e2e8f0; line-height: 1.7; margin-top: 10px;
}
.tt-blog {
    background: rgba(34,197,94,0.1);
    border-left: 3px solid #22c55e;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px; font-size: 0.84rem;
    color: #bbf7d0; line-height: 1.7; margin-top: 6px;
}
.tt-badge-sit {
    display: inline-block;
    background: linear-gradient(135deg, #7048e8, #3b5bdb);
    color: white; border-radius: 20px;
    padding: 3px 11px; font-size: 0.8rem; font-weight: 700;
    margin-right: 4px; margin-bottom: 4px;
}
.tt-badge-dist {
    display: inline-block;
    background: rgba(251,191,36,0.2);
    color: #fbbf24; border-radius: 20px;
    padding: 3px 11px; font-size: 0.8rem; font-weight: 600;
    margin-right: 4px; margin-bottom: 4px;
    border: 1px solid rgba(251,191,36,0.4);
}
.tt-rank {
    display: inline-flex; align-items: center; justify-content: center;
    color: white; border-radius: 50%;
    width: 28px; height: 28px; font-weight: 700; font-size: 0.88rem;
    margin-right: 8px; flex-shrink: 0;
    background: linear-gradient(135deg, #3b5bdb, #7048e8);
}
.tt-rank-gold   { background: linear-gradient(135deg, #f59f00, #e67700) !important; }
.tt-rank-silver { background: linear-gradient(135deg, #868e96, #495057) !important; }
.tt-rank-bronze { background: linear-gradient(135deg, #a0522d, #7b3f00) !important; }
.tt-star { color: #fbbf24; }
.tt-engine-badge {
    display: inline-block; background: linear-gradient(90deg, #7048e8, #3b5bdb);
    color: white; border-radius: 6px; padding: 1px 8px;
    font-size: 0.72rem; font-weight: 700; margin-left: 6px; vertical-align: middle;
}
.tt-section-title {
    font-size: 1rem; color: #94a3b8; font-weight: 600;
    margin: 12px 0 8px 0; padding-left: 4px;
    border-left: 3px solid #7048e8; padding-left: 10px;
}
.tt-divider { border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 16px 0; }
h1,h2,h3,h4 { color: #f8fafc !important; }
p, label, .stMarkdown { color: #e2e8f0 !important; }
.stExpander {
    background: rgba(255,255,255,0.05) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
    border-radius: 10px !important;
}
</style>
""", unsafe_allow_html=True)


# ── 유틸 ─────────────────────────────────────────────────────
def _s(v, default=""):
    if v is None: return default
    return re.sub(r"<[^>]+>", "", str(v)).strip() or default

def _rank_cls(rank):
    return {1:"tt-rank tt-rank-gold",2:"tt-rank tt-rank-silver",3:"tt-rank tt-rank-bronze"}.get(rank,"tt-rank")

def _stars(score):
    n = min(5, max(0, int(round(float(score)/2))))
    return "★"*n + "☆"*(5-n)

def _extract_keywords(query: str) -> list[str]:
    kws = ["혼밥","혼자","데이트","커플","가족","친구","회식","가성비",
           "저렴","분위기","감성","주차","단체","아이동반"]
    return [k for k in kws if k in query]


# ── 카드 렌더링 ──────────────────────────────────────────────
def render_card(col, rank: int, r: dict, mode: str = "search"):
    name     = _s(r.get("name"),         "이름 없음")
    cat      = _s(r.get("category"),     "")
    addr     = _s(r.get("address"),      r.get("address_hint","주소 정보 없음"))
    link     = _s(r.get("link"),         f"https://map.naver.com/v5/search/{urlparse.quote(name)}")
    reason   = _s(r.get("reason"),       "")
    hi       = _s(r.get("highlight"),    "")
    score    = float(r.get("score",      7.0))
    s_tags   = [_s(t) for t in r.get("situation_tags",[]) if t]
    blog_sum = _s(r.get("blog_summary"), "")
    dist_str = r.get("distance_str",     "")

    rc     = _rank_cls(rank)
    st_str = _stars(score)
    badge  = "AI 추천" if mode == "search" else "근처 맛집"

    tags_html = ""
    if dist_str:
        tags_html += f'<span class="tt-badge-dist">📍 {dist_str}</span>'
    for t in s_tags:
        tags_html += f'<span class="tt-badge-sit">{t}</span>'

    reason_html = f'<div class="tt-reason">💡 {reason}</div>' if reason else ""
    blog_html   = f'<div class="tt-blog">⭐ 블로그 분석<br>{blog_sum}</div>' if blog_sum else ""

    card = f"""<div class="tt-card">
  <div style="display:flex;align-items:flex-start;gap:6px;">
    <span class="{rc}">{rank}</span>
    <div style="flex:1;min-width:0;">
      <div class="tt-card-title">{name}<span class="tt-engine-badge">{badge}</span></div>
      {f'<div class="tt-highlight">✨ {hi}</div>' if hi else ""}
      {f'<div style="margin-top:6px;">{tags_html}</div>' if tags_html else ""}
      <div class="tt-meta">
        <span class="tt-star">{st_str}</span>&nbsp;<strong>{score:.1f}</strong>/10<br>
        {f"🍽️ {cat}<br>" if cat else ""}
        📍 {addr}
      </div>
    </div>
  </div>
  {reason_html}
  {blog_html}
</div>"""

    col.markdown(card, unsafe_allow_html=True)
    col.markdown(f"[🗺️ 네이버 지도에서 보기]({link})")


def render_results(results, mode="search", label=""):
    if not results:
        return
    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
    has_blog = any(r.get("blog_summary") for r in results)
    engine   = "블로그 분석 반영순" if has_blog else ("거리순" if mode=="nearby" else "AI 추천순")
    st.markdown(
        f'### 🌟 {label}<span class="tt-engine-badge">{engine}</span>',
        unsafe_allow_html=True,
    )
    if has_blog:
        st.markdown(
            '<div style="color:#86efac;font-size:0.84rem;margin-bottom:10px;">'
            '📝 네이버 블로그 후기 분석 결과가 순위에 반영되었습니다.</div>',
            unsafe_allow_html=True,
        )
    top3 = results[:3]
    rest = results[3:]
    cols = st.columns(3)
    for i, (col, r) in enumerate(zip(cols, top3)):
        try:    render_card(col, i+1, r, mode)
        except Exception as e: col.error(f"카드 오류: {e}")
    if rest:
        st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
        st.markdown("#### 🔖 추가 추천")
        rcols = st.columns(len(rest))
        for i, (col, r) in enumerate(zip(rcols, rest)):
            try:    render_card(col, i+4, r, mode)
            except Exception as e: col.error(f"카드 오류: {e}")
    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
    st.caption("🌳 Tastetree — AI 기반 맛집 탐색기 | Powered by OpenAI · Naver · Kakao")


# ── 검색 파이프라인 ──────────────────────────────────────────
def run_search(location: str, query: str, time_of_day: str) -> list[dict]:
    user_kws = _extract_keywords(query)

    # STEP1: AI가 후보 10개 생성
    with st.spinner("🤖 AI가 맛집 후보를 선별 중…"):
        candidates = generate_candidates(
            location=location,
            user_request=query,
            time_of_day=time_of_day,
            n=10,
        )
    if not candidates:
        st.warning("추천 결과를 생성하지 못했습니다. 요청을 구체적으로 입력해보세요.")
        return []

    # STEP2: 카카오로 주소 + 네이버맵 링크 보완
    with st.spinner("📍 식당 위치 정보 확인 중…"):
        try:    candidates = enrich(candidates, location)
        except: pass

    # STEP3: 네이버 블로그 병렬 분석 (10개 동시)
    with st.spinner("🔮 테이스트리 AI가 실시간 블로그 후기를 분석하여 취향 저격 순위를 계산 중입니다..."):
        try:
            blog_data = analyze_all(candidates, user_keywords=user_kws, max_workers=5)
        except Exception:
            blog_data = {}

    # STEP4: 블로그 결과 병합 + 점수 계산 → 상위 5개
    for i, r in enumerate(candidates):
        name = r.get("name","")
        bd   = blog_data.get(name, {})
        r["situation_tags"] = bd.get("situation_tags", [])
        r["blog_summary"]   = bd.get("blog_summary",   "")
        # 점수: 기본 8.5 - 순위패널티 + 블로그태그 보너스
        base  = 8.5 - i * 0.4
        bonus = len(r["situation_tags"]) * 0.25
        # 사용자 키워드 매칭 보너스
        match = sum(1 for t in r["situation_tags"] if any(uk in t for uk in user_kws))
        r["score"] = round(min(10.0, base + bonus + match * 0.3), 1)

    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[:5]


# ── 근처 맛집 파이프라인 ─────────────────────────────────────
def run_nearby(lat: float, lon: float) -> list[dict]:
    with st.spinner("📡 근처 맛집을 찾는 중…"):
        nearby = get_nearby_restaurants(lat, lon, radius=1000, size=10)
    if not nearby:
        st.warning("근처 식당을 찾지 못했습니다.")
        return []

    # 블로그 분석으로 상황 태그 추가
    with st.spinner("🔮 테이스트리 AI가 근처 맛집 후기를 분석 중입니다..."):
        try:
            blog_data = analyze_all(nearby[:5], user_keywords=[], max_workers=5)
            for r in nearby[:5]:
                name = r.get("name","")
                bd   = blog_data.get(name, {})
                r["situation_tags"] = bd.get("situation_tags", [])
                r["blog_summary"]   = bd.get("blog_summary",   "")
                bonus = len(r["situation_tags"]) * 0.2
                r["score"] = round(min(10.0, 7.0 + bonus), 1)
        except Exception:
            pass

    return nearby[:5]


# ── 메인 ─────────────────────────────────────────────────────
def main():
    # session_state 초기화
    for k, v in [
        ("search_results", None),
        ("nearby_results", None),
        ("detected_loc",   ""),
        ("lat", None), ("lon", None),
        ("last_query", ""),
    ]:
        if k not in st.session_state:
            st.session_state[k] = v

    # 시간
    KST = datetime.timezone(datetime.timedelta(hours=9))
    ts  = datetime.datetime.fromtimestamp(time.time(), tz=KST)
    y,m,d   = str(ts).split()[0].split("-")
    h       = int(str(ts).split()[1].split(":")[0])
    cur_time = "아침" if h<11 else "점심" if h<17 else "저녁"
    weekday  = ["월","화","수","목","금","토","일"][ts.weekday()]

    # 헤더
    st.markdown(f"""
<div style="padding:8px 0 2px 0;">
  <h1 style="margin:0;font-size:2rem;color:white;">
    🌳 Tastetree
    <span style="font-weight:400;color:#94a3b8;font-size:1.2rem;">: AI 기반 맛집 탐색기</span>
  </h1>
  <p style="color:#64748b;font-size:0.9rem;margin-top:4px;">
    당신의 취향과 상황에 딱 맞는 맛집을 AI가 직접 추천합니다
  </p>
</div>
""", unsafe_allow_html=True)
    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)

    # 상태 표시
    c1, c2, c3 = st.columns(3)
    c1.metric("📅 날짜", f"{y}.{m}.{d} ({weekday})")
    c2.metric("⏰ 시간대", cur_time)

    # 위치 입력 + GPS 버튼
    # get_geolocation()은 매 렌더링마다 호출 → 결과를 session_state에 캐싱
    # (버튼 클릭 시 리렌더링되므로 두 번째 렌더에서 좌표가 들어옴)
    geo = get_geolocation()
    if geo and geo.get("coords"):
        st.session_state["lat"] = geo["coords"]["latitude"]
        st.session_state["lon"] = geo["coords"]["longitude"]

    with c3:
        cur_loc = st.text_input(
            "📍 현재 위치",
            value=st.session_state["detected_loc"],
            placeholder="예: 서울 강남구  또는  아래 버튼으로 자동 감지",
        )
        if st.button("📡 내 위치 자동 감지", use_container_width=True):
            lat = st.session_state.get("lat")
            lon = st.session_state.get("lon")
            if lat and lon:
                adm = reverse_geocode_kakao(lat, lon)
                if adm and len(adm) >= 2:
                    st.session_state["detected_loc"] = f"{adm[0]} {adm[1]}"
                    nearby = run_nearby(lat, lon)
                    st.session_state["nearby_results"] = nearby
                    st.rerun()
                else:
                    st.warning("위치 변환 실패. 직접 입력해주세요.")
            else:
                st.warning("브라우저에서 위치 권한을 허용해주세요. 허용 후 다시 눌러주세요.")

    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)

    # 근처 맛집 자동 표시 (GPS 허용 시)
    if st.session_state.get("nearby_results"):
        render_results(
            st.session_state["nearby_results"],
            mode="nearby",
            label=f"📡 내 주변 맛집 Top {len(st.session_state['nearby_results'])}",
        )
        st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)

    # 검색 입력
    st.markdown("### 🔎 맛집 탐색 요청")
    triggered = False
    query     = ""

    query = st.text_input(
        "요청사항을 자유롭게 입력하세요",
        placeholder="예: 혼밥하기 좋은 국밥집, 데이트 분위기 파스타, 가족 외식 한식당",
    )
    if st.button("🌳 AI 맛집 탐색 시작!", type="primary"):
        triggered = True

    # 검색 실행
    if triggered and query.strip():
        location = cur_loc.strip() if cur_loc.strip() else (
            st.session_state.get("detected_loc","") or "서울"
        )
        st.session_state["search_results"] = None
        st.session_state["last_query"]     = query

        st.markdown(
            f'<div style="color:#94a3b8;font-size:0.85rem;margin:8px 0 12px 0;">'
            f'📍 {location} | ⏰ {cur_time} | 🔑 {query}</div>',
            unsafe_allow_html=True,
        )
        results = run_search(location, query, cur_time)
        st.session_state["search_results"] = results

    # 검색 결과 렌더링
    if st.session_state.get("search_results"):
        render_results(
            st.session_state["search_results"],
            mode="search",
            label=f"AI 추천 맛집 Top {len(st.session_state['search_results'])}",
        )
    elif st.session_state.get("last_query") and not triggered:
        st.info("검색 결과가 없습니다. 다른 요청으로 시도해보세요.")


if __name__ == "__main__":
    main()
