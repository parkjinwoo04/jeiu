import streamlit as st
from streamlit.components.v1 import html
from streamlit_js_eval import streamlit_js_eval, get_user_agent, get_geolocation
import json
import time, datetime
import pandas as pd
import numpy as np
import random
import requests
import urllib.parse
from utils.time_and_locations import reverse_geocode, get_geocode
from utils.clova_speech import get_clova_stt

from utils.openai_agent import get_search_query, get_order_type, get_review
from utils.kakao_search import get_place_info 

st.set_page_config(layout="wide", page_title="테이스트리 - 오늘 뭐먹지?", page_icon="🍴")

def get_real_market_image(restaurant_name, address):
    try:
        kakao_rest_api_key = "2369680b57e78dca9a101b0bbf80b889"
        headers = {"Authorization": f"KakaoAK {kakao_rest_api_key}"}
        region = address.split()[1] if len(address.split()) > 1 else ""
        search_keyword = f"{region} {restaurant_name}"
        url = f"https://dapi.kakao.com/v2/search/image?query={urllib.parse.quote(search_keyword)}&display=1"
        res = requests.get(url, headers=headers, timeout=4)
        if res.status_code == 200:
            documents = res.json().get('documents', [])
            if documents:
                return documents[0]['image_url']
    except:
        pass
    return None

def main():
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Bagel+Fat+One&family=Pretendard:wght@400;500;600;700&display=swap');
        
        html, body, [data-testid="stAppViewContainer"], [data-testid="stHeader"] {
            font-family: 'Pretendard', sans-serif;
            background-color: #fff6e9 !important;
            color: #2b2b2b;
        }

        .tastetry-header {
            background: linear-gradient(135deg, #ff9f43 0%, #ff7a00 100%);
            padding: 5rem 3rem 3rem 3rem;
            border-radius: 40px;
            color: white;
            text-align: left;
            position: relative;
            overflow: hidden;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(255, 122, 0, 0.15);
        }
        .tastetry-header::before {
            content: "🍔";
            position: absolute;
            right: 40px;
            top: 20px;
            font-size: 120px;
            opacity: 0.15;
        }
        .tastetry-header::after {
            content: "🍟";
            position: absolute;
            bottom: -10px;
            right: 150px;
            font-size: 100px;
            opacity: 0.12;
        }
        .tastetry-header h1 {
            font-family: 'Bagel Fat One', cursive !important;
            color: white !important;
            font-size: 3.8rem !important;
            line-height: 1.2 !important;
            margin-bottom: 1rem !important;
        }
        .tastetry-header p {
            font-size: 1.25rem;
            opacity: 0.95;
            margin-bottom: 2rem;
        }

        .tastetry-card {
            background-color: white;
            border-radius: 28px;
            padding: 0px;
            margin-bottom: 1.5rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.07);
            border: none;
            overflow: hidden;
            transition: transform 0.25s ease;
        }
        .tastetry-card:hover {
            transform: translateY(-10px);
        }
        .card-padded-body {
            padding: 22px;
        }

        .tastetry-tag {
            display: inline-block;
            background: #fff0df;
            color: #ff7a00;
            padding: 8px 14px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 14px;
        }
        .tastetry-title {
            font-size: 24px;
            font-weight: 800;
            color: #2b2b2b;
            margin-bottom: 10px;
        }
        .tastetry-rating {
            color: #ffb800;
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        div[data-testid="stForm"], div[data-testid="stExpander"] {
            background-color: white !important;
            border-radius: 20px !important;
            border: 1px solid #ffe0b2 !important;
        }
        
        .stButton>button {
            background-color: #ff7a00 !important;
            color: white !important;
            border: none !important;
            border-radius: 999px !important;
            font-weight: 700 !important;
            transition: 0.2s !important;
        }
        .stButton>button:hover {
            background-color: #ff5e00 !important;
            transform: scale(1.02) !important;
        }

        .category-container {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            margin-top: 1rem;
        }
        div[data-testid="stHorizontalBlock"] .stButton>button {
            background-color: white !important;
            color: #2b2b2b !important;
            padding: 10px 20px !important;
            border-radius: 999px !important;
            font-weight: 700 !important;
            border: none !important;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08) !important;
        }
        div[data-testid="stHorizontalBlock"] .stButton>button:hover {
            background-color: #ffe3c2 !important;
            transform: translateY(-3px) !important;
        }
        </style>
    """, unsafe_allow_html=True)

    if "search_result" not in st.session_state:
        st.session_state.search_result = pd.DataFrame()
    if "final_candidates" not in st.session_state:
        st.session_state.final_candidates = False
    if "review_summaries" not in st.session_state:
        st.session_state.review_summaries = {}
    if "search_input_value" not in st.session_state:
        st.session_state.search_input_value = ""
    if "trigger_search" not in st.session_state:
        st.session_state.trigger_search = False

    KST = datetime.timezone(datetime.timedelta(hours=9))
    timestamp = datetime.datetime.fromtimestamp(time.time(), tz=KST)
    year, month, day = str(timestamp).split()[0].split(sep='-')
    cur_time = int(str(timestamp).split()[1].split(":")[0])
    if cur_time < 11:
         cur_time = "아침"
    elif cur_time < 17:
         cur_time = "점심"
    else:
         cur_time = "저녁"
    weekday = ["월", "화", "수", "목", "금", "토", "일"][timestamp.weekday()]

    try:
        loc = get_geolocation()
        latitude = loc['coords']['latitude']
        longitude = loc['coords']['longitude']
        geocode = f"{longitude},{latitude}"
        admcode = reverse_geocode(geocode)
    except:
        admcode = ("서울시", "성동구", "성수동")

    parsed_cmd = None
    cur_loc = admcode[1]

    st.markdown(f"""
        <div class="tastetry-header">
            <h1>무엇을<br>먹어볼까요? 😋</h1>
            <p>지금 가장 핫한 맛집을 찾아보세요!</p>
        </div>
    """, unsafe_allow_html=True)

    header_placeholder = st.empty()

    meta_col1, meta_col2, meta_col3 = st.columns(3)
    with meta_col1:
        st.text_input("📅 탐색 날짜", f"{year}년 {month}월 {day}일 ({weekday})", disabled=True)
    with meta_col2:
        st.text_input("⏰ 추천 시간대", f"현재 기준 '{cur_time}'", disabled=True)
    with meta_col3:
        cur_loc = st.text_input("📍 설정 위치", f"{admcode[1]}")

    st.write("")
    debug = st.checkbox("⚙️ 개발자 데이터 로그 모니터링", value=False)

    with st.container():
        st.markdown("<div style='background-color:white; padding:1.5rem; border-radius:28px; box-shadow:0 10px 25px rgba(0,0,0,0.05); border:3px solid #ffe0b2;'>", unsafe_allow_html=True)
        input_type = st.selectbox("🎙️ 요청 방식을 선택하세요", options=["텍스트 검색", "음성 인식 명령"])
        
        if input_type == "음성 인식 명령":
            col1, col2 = st.columns([1, 4])
            with col1:
                audio_bytes = audio_recorder(
                    text="말하기",
                    recording_color="#ff7a00",
                    neutral_color="#2b2b2b",
                    icon_name="microphone",
                    icon_size="3x",
                )
            with col2:
                if audio_bytes:
                    with st.spinner("음성 분석 중..."):
                        query_audio = get_clova_stt(audio_bytes).get("text", None)
                    if query_audio:
                        st.info(f"🗣️ 인식된 음성: **{query_audio}**")
                        parsed_cmd = {"loc": cur_loc, "pref": query_audio, "time": cur_time}
                else:
                    st.caption("마이크 버튼을 누르고 말씀하세요.")
        
        elif input_type == "텍스트 검색":
            query_text = st.text_input("💬 어떤 음식을 드시고 싶으신가요?", value=st.session_state.search_input_value, placeholder="지역, 음식, 맛집 검색")
            
            st.markdown("<p style='font-weight:700; margin-top:10px; margin-bottom:5px; font-size:14px; color:#666;'>추천 카테고리</p>", unsafe_allow_html=True)
            cat_cols = st.columns(6)
            categories = ["🍗 치킨", "🍜 라멘", "🍔 햄버거", "☕ 카페", "🍖 고기", "🍰 디저트"]
            
            for idx, cat_name in enumerate(categories):
                with cat_cols[idx]:
                    if st.button(cat_name, key=f"cat_{idx}"):
                        keyword = cat_name.split()[-1]
                        st.session_state.search_input_value = keyword
                        st.session_state.trigger_search = True
                        st.rerun()

            if st.button("검색", width='stretch') or st.session_state.trigger_search:
                search_keyword = st.session_state.search_input_value if st.session_state.trigger_search else query_text
                st.session_state.trigger_search = False
                
                if search_keyword:
                    with st.spinner("요청 파싱 중"):
                        parsed_cmd = {"loc": cur_loc, "pref": search_keyword, "time": cur_time}
                        for time_keyword in ["아침", "점심", "저녁"]:
                            if time_keyword in search_keyword:
                                parsed_cmd["time"] = time_keyword
        st.markdown("</div>", unsafe_allow_html=True)

    spinner_loc = st.empty()
    
    if parsed_cmd is not None:
        st.session_state.final_candidates = False
        st.session_state.review_summaries = {}
        
        if parsed_cmd['time'] == "없음":
            parsed_cmd['time'] = cur_time
        if parsed_cmd['loc'] == "없음":
            parsed_cmd["loc"] = cur_loc
            
        with st.expander("🔍 백엔드 파이프라인 로그", expanded=debug):        
            st.write(parsed_cmd)
            with spinner_loc:
                with st.spinner("쿼리 빌딩 중"):
                    search_query = get_search_query(loc=parsed_cmd['loc'], pref=parsed_cmd['pref'])
            st.write(search_query)
            
            search_result = pd.DataFrame()
            with spinner_loc:
                with st.spinner("카카오 데이터 수집 중"):
                    for _query in search_query.get("query", []):
                        try:
                            res = get_place_info(_query)
                            if res is not None and not res.empty:
                                search_result = pd.concat((search_result, res))
                        except:
                            continue
            
            if not search_result.empty:
                if "clean_title" in search_result.columns:
                    search_result = search_result.drop_duplicates(subset=["clean_title"]).reset_index(drop=True)

                    with spinner_loc:
                        with st.spinner("카테고리 필터링 중"):
                            menu_analysis = get_order_type(instruction=parsed_cmd['pref'])
                    target_to_remove = menu_analysis.get("targets", [])

                    if "category" in search_result.columns and target_to_remove:
                        filtered_idx = []
                        for cat in search_result["category"]:
                            is_target = False
                            for target in target_to_remove:
                                if target in str(cat):
                                    is_target = True
                                    break
                            filtered_idx.append(not is_target)
                        search_result = search_result[filtered_idx]

                    # 💡 [보완] 검색어가 '빵' 종류일 때 타 업종(고깃집 등)이 노출되지 않도록 강제 유관 카테고리 매칭 필터
                    user_keyword = parsed_cmd['pref'].strip()
                    if user_keyword and user_keyword not in ["맛집", "점심", "저녁", "아침", "추천"]:
                        keep_idx = []
                        for cat in search_result["category"]:
                            cat_str = str(cat)
                            # 검색어가 카테고리에 포함되거나, '빵' 관련 대표 카테고리 키워드 매칭 검사
                            if user_keyword in cat_str:
                                keep_idx.append(True)
                            elif user_keyword in ["빵", "베이커리", "디저트"] and any(k in cat_str for k in ["카페", "베이커리", "제과"]):
                                keep_idx.append(True)
                            else:
                                keep_idx.append(False)
                        
                        if any(keep_idx):
                            search_result = search_result[keep_idx]

                    st.write(search_result)

                    sample_size = min(len(search_result), 3)
                    if sample_size > 0:
                        search_result = search_result.sample(n=sample_size).reset_index(drop=True)
                        st.session_state.search_result = search_result
                        st.session_state.final_candidates = True
            else:
                with spinner_loc:
                    st.warning("결과를 찾을 수 없습니다.")

    if st.session_state.final_candidates and not st.session_state.search_result.empty:
        st.markdown("<h2 style='margin-top: 2.5rem; margin-bottom: 1.5rem; font-weight:800;'>🔥 지금 뜨는 맛집</h2>", unsafe_allow_html=True)
        
        result_df = st.session_state.search_result
        columns = st.columns(len(result_df.index))
        
        for i, col in enumerate(columns):
            row = result_df.iloc[i]
            title = row['clean_title']
            address = row['address'] if 'address' in row else (row['roadAddress'] if 'roadAddress' in row else '주소 정보 없음')
            category = row['category'] if 'category' in row else '음식점'
            link = row['link'] if 'link' in row and row['link'] else f"https://map.kakao.com/?q={title}"
            description = row['description'] if 'description' in row and str(row['description']) != 'nan' else f"{title}은(는) 해당 지역 인기 매장입니다."

            sub_category = category.split('>')[-1].strip() if '>' in category else category
            short_addr = " · ".join(address.split()[:2])

            with col:
                st.markdown(f"""
                    <div class="tastetry-card">
                        <div class="card-padded-body" style="padding-bottom:0px;">
                            <div class="tastetry-tag">#{sub_category}</div>
                            <div class="tastetry-title">{title}</div>
                            <div class="tastetry-rating">⭐ 4.7 (추천)</div>
                        </div>
                    </div>
                """, unsafe_allow_html=True)

                with st.spinner(f"{title} 관련 이미지 찾는 중..."):
                    real_img_url = get_real_market_image(title, address)
                
                if not real_img_url:
                    seed_num = random.randint(1, 99999)
                    clean_kw = sub_category.replace("/", ",").replace(" ", "")
                    real_img_url = f"https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80&sig={seed_num}&keyword={urllib.parse.quote(clean_kw)}"

                st.image(real_img_url, width='stretch')

                with st.expander("📍 위치 확인 및 지도", expanded=False):
                    try:
                        x, y = get_geocode(address)
                        df_geocode = pd.DataFrame([[float(y), float(x)]], columns=['lat', 'lon'])
                        st.map(df_geocode)
                    except:
                        if 'mapx' in row and 'mapy' in row and row['mapx'] and row['mapy']:
                            try:
                                df_geocode = pd.DataFrame([[float(row['mapy']), float(row['mapx'])]], columns=['lat', 'lon'])
                                st.map(df_geocode)
                            except:
                                st.caption("📍 지도 가져오기 실패")

                st.markdown(f"""
                    <div style="padding: 0 10px; color:#666; font-size:15px; line-height:1.5; margin-bottom:10px;">
                        {short_addr} · {description}
                    </div>
                """, unsafe_allow_html=True)
                
                st.markdown(f'<a href="{link}" target="_blank"><button style="width:100%; padding:10px; background-color:#ff7a00; color:white; border:none; border-radius:999px; font-weight:700; cursor:pointer; margin-top:5px; margin-bottom:15px;">상세 정보 보기 ↗</button></a>', unsafe_allow_html=True)

                try:
                    if title not in st.session_state.review_summaries:
                        with st.spinner("🤖 AI 한줄평 생성 중..."):
                            summary_text = get_review(f"식당명: {title}, 업종: {category}, 설명: {description}, 주소: {address}")
                            st.session_state.review_summaries[title] = summary_text

                    with st.container():
                        st.markdown("<div style='background-color:#fffaf3; padding:15px; border-radius:20px; border:2px solid #ffe0b2; font-size:0.95rem; line-height:1.6;'>", unsafe_allow_html=True)
                        st.markdown(f"**🤖 AI 매거진 추천사** \n{st.session_state.review_summaries[title]}")
                        st.markdown("</div>", unsafe_allow_html=True)
                except Exception as e:
                    st.caption("⚠️ OpenAI API 인증 에러로 인해 AI 매거진 한줄평 기능을 임시 제한합니다.")
            
if __name__ == '__main__':
    main()