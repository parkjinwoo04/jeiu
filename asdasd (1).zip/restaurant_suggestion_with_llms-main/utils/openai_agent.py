import os
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# 🔥 [중요] 반드시 작동하는 본인의 올바른 OpenAI API Key로 교체해 주세요!
os.environ["OPENAI_API_KEY"] = "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"

# 1. 맛집 검색어 및 도구 추출을 위한 LLM 설정 (카카오맵 기준으로 최적화)
search_query_prompt = ChatPromptTemplate.from_messages([
    ("system", """당신은 사용자의 요구사항과 위치를 기반으로 맛집을 검색하기 위한 적절한 도구와 검색어를 생성하는 전문가입니다.
반드시 아래의 출력 형식을 엄격하게 지켜서 답변하세요. 다른 설명이나 인사말은 절대 하지 마세요.

출력 형식:
도구: 카카오맵
검색어: 지역 맛집1, 지역 맛집2"""),
    ("user", "지역: {loc}\n요구사항: {pref}")
])

# 기본 LLM 선언 (속도가 빠르고 비용이 저렴한 gpt-4o-mini 모델 활용)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7) # 요약과 상상력을 위해 온도를 0.7로 살짝 올림
search_query_chain = search_query_prompt | llm | StrOutputParser()


def get_search_query(loc, pref):
    """사용자 요청에 맞는 검색 도구와 키워드를 반환합니다."""
    # 에러 방지를 위한 기본 안전 장치(Default 값도 카카오맵으로 변경)
    tool = "카카오맵"
    query = [f"{loc} 맛집"]
    
    try:
        # LLM 호출
        result_text = search_query_chain.invoke({"loc": loc, "pref": pref})
        
        if not result_text:
            return {"tool": tool, "query": query}
            
        # 줄바꿈 단위로 쪼개서 한 줄씩 검사
        result = result_text.strip().split('\n')
        
        for line in result:
            line = line.strip()
            if not line:
                continue
                
            # '도구:' 문자가 포함되어 있다면 안전하게 파싱
            if "도구" in line and ":" in line:
                try:
                    tool = line.split(":")[1].strip()
                except IndexError:
                    pass
            # '검색어:' 문자가 포함되어 있다면 안전하게 쉼표 단위로 파싱
            elif "검색어" in line and ":" in line:
                try:
                    raw_queries = line.split(":")[1].strip()
                    if raw_queries:
                        query = [text.strip() for text in raw_queries.split(",") if text.strip()]
                except IndexError:
                    pass
                    
        # 2차 방어선: 무엇이 들어오든 우리 앱은 이제 카카오맵 전용이므로 강제 통일
        tool = "카카오맵"
            
    except Exception as e:
        # LLM 자체가 실패하더라도 프로그램이 멈추지 않게 방어
        pass

    return {"tool": tool, "query": query}


# 2. 부적절한 메뉴 필터링을 위한 함수 (기존 구조 안정화)
def get_order_type(instruction):
    try:
        # Streamlit 메인 앱의 필터 기능을 위한 안전한 더미 데이터 구조 반환
        return {"type": "필터", "targets": []}
    except:
        return {"type": "필터", "targets": []}


# 3. 리뷰 요약을 위한 함수 (★ 핵심 수정 구역 ★)
def get_review(review_text):
    """
    카카오맵 API로부터 전달받은 식당 기본 정보(텍스트)를 바탕으로 
    AI 에디터 스타일의 매력적인 추천사 2~3줄을 생성합니다.
    """
    try:
        summary_prompt = ChatPromptTemplate.from_messages([
            ("system", (
                "당신은 전국의 숨은 맛집을 소개하는 푸드 에디터이자 AI 추천 전문가입니다. "
                "제공된 식당의 정보(이름, 카테고리, 위치 등)를 바탕으로 이 식당이 가질 만한 매력, "
                "추천 메뉴 제안, 혹은 방문하기 좋은 타이밍을 포함하여 친절하고 감성적인 'AI 추천 특징'을 딱 2~3줄로 작성해 주세요. "
                "전달받은 텍스트에 상세한 설명이 없더라도 식당 이름과 업종 분류(예: 일식, 카페 등)를 기반으로 "
                "전문가다운 상상력을 발휘하여 자연스럽고 매력적인 문장으로 지어내야 합니다. 절대로 정보가 부족하다는 변명을 하지 마세요."
            )),
            ("user", "{reviews}")
        ])
        
        summary_chain = summary_prompt | llm | StrOutputParser()
        response = summary_chain.invoke({"reviews": review_text})
        return response.strip()

    except Exception as e:
        # 💡 API Key가 아예 유효하지 않거나 네트워크가 단절되는 최악의 상황 시 출력될 부드러운 방어 문구
        print(f"OpenAI API 호출 에러 발생: {e}")
        return "🎵 카카오 맵 링크를 클릭하시면 실제 방문자들의 생생한 별점과 영수증 리뷰를 바로 확인하실 수 있습니다!"