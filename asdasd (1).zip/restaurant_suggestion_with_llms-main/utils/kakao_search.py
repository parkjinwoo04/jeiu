import requests
import pandas as pd

# 카카오 개발자 센터에서 발급받은 REST API 키 입력
# 예: KAKAO_REST_KEY = "123456789abcdefg..."
KAKAO_REST_KEY = "4aecc041fa065b2ed7e6f6ead77619f4"

headers = {
    "Authorization": f"KakaoAK {KAKAO_REST_KEY}"
}

def get_place_info(query, display=15, sort="accuracy"):
    """
    카카오 로컬 API - 키워드로 장소 검색
    - sort: 'accuracy'(정확도순) 또는 'distance'(거리순)
    - display: 한 페이지에 보여질 문서 수 (1~15)
    """
    url = "https://dapi.kakao.com/v2/local/search/keyword.json"
    params = {
        "query": query,
        "size": display,
        "sort": sort
    }
    
    try:
        response = requests.get(url=url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            documents = data.get('documents', [])
            
            df = pd.DataFrame(documents)
            if not df.empty:
                # 💡 Streamlit 메인 코드와 100% 호환되도록 카카오 키명을 네이버 키명 스타일로 변환
                rename_dict = {
                    'place_name': 'clean_title',       # 식당 이름
                    'address_name': 'address',         # 지번 주소
                    'road_address_name': 'roadAddress',   # 도로명 주소
                    'category_name': 'category',       # 카테고리
                    'place_url': 'link',               # 카카오맵 링크
                    'x': 'mapx',                       # 경도
                    'y': 'mapy'                        # 위도
                }
                existing_rename = {k: v for k, v in rename_dict.items() if k in df.columns}
                df = df.rename(columns=existing_rename)
                
                # title 컬럼 기본 백업 생성
                df['title'] = df['clean_title']
            return df
        else:
            print(f"Kakao API Error({response.status_code}): {response.text}")
            return pd.DataFrame()
    except Exception as e:
        print(f"Kakao API Request Exception: {e}")
        return pd.DataFrame()