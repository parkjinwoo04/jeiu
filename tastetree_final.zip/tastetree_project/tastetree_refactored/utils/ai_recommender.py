"""
ai_recommender.py
OpenAI가 후보 식당 10개를 생성하고
네이버 블로그 total 기반으로 상황 태그를 부여해 상위 5개를 선정.
"""
import json, re
from openai import OpenAI

OPENAI_API_KEY = ""  # ← OpenAI API 키

client = OpenAI(api_key=OPENAI_API_KEY)


def generate_candidates(
    location: str,
    user_request: str,
    time_of_day: str = "",
    n: int = 10,
) -> list[dict]:
    """
    OpenAI에게 후보 식당 n개를 요청.
    실제 존재하는 식당만 추천하도록 프롬프트 설계.
    """
    time_hint = f"{time_of_day} 식사로 " if time_of_day and time_of_day != "없음" else ""

    prompt = f"""당신은 한국 맛집 전문가입니다.
아래 조건에 맞는 실제 존재하는 식당 {n}곳을 추천하세요.

[조건]
- 지역: {location}
- 요청: {user_request}
- 시간대: {time_hint if time_hint else "무관"}

[규칙]
1. 반드시 실제로 존재하고 영업 중인 식당만 (지어낸 이름 절대 금지)
2. 해당 지역에서 실제로 유명하거나 후기가 많은 곳
3. 사용자 요청 상황(혼밥/데이트/가족/가성비 등)에 맞는 곳 우선
4. reason은 순수 텍스트 2문장 (HTML 금지)
5. highlight는 10자 이내

JSON 배열만 출력. 다른 텍스트 없음.
[
  {{
    "name": "실제 식당 이름",
    "category": "음식 종류",
    "reason": "추천 이유 2문장",
    "highlight": "핵심 한 줄",
    "address_hint": "OO동 또는 OO역 근처"
  }}
]
총 {n}개."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=3000,
        )
        raw = response.choices[0].message.content.strip()
        raw = re.sub(r"```json|```", "", raw).strip()
        match = re.search(r"\[[\s\S]*\]", raw)
        if match:
            raw = match.group(0)
        results = json.loads(raw)
        cleaned = []
        for r in results[:n]:
            cleaned.append({
                "name":         re.sub(r"<[^>]+>","",str(r.get("name",""))).strip(),
                "category":     re.sub(r"<[^>]+>","",str(r.get("category",""))).strip(),
                "reason":       re.sub(r"<[^>]+>","",str(r.get("reason",""))).strip(),
                "highlight":    re.sub(r"<[^>]+>","",str(r.get("highlight",""))).strip(),
                "address_hint": re.sub(r"<[^>]+>","",str(r.get("address_hint",""))).strip(),
            })
        return cleaned
    except Exception as e:
        print(f"후보 생성 오류: {e}")
        return []
