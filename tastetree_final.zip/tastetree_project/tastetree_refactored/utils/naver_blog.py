"""
naver_blog.py
네이버 블로그 API:
1. 식당별 상황 키워드 total 수 → 상황 태그 동적 생성
2. 블로그 본문 발췌 → OpenAI 요약
"""
import requests, re, json
from urllib import parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from openai import OpenAI

NAVER_CLIENT_ID     = ""  # ← 네이버 Client ID
NAVER_CLIENT_SECRET = ""  # ← 네이버 Client Secret
OPENAI_API_KEY      = ""  # ← OpenAI API 키

_nv = {
    "X-Naver-Client-Id":     NAVER_CLIENT_ID,
    "X-Naver-Client-Secret": NAVER_CLIENT_SECRET,
}
_oai = OpenAI(api_key=OPENAI_API_KEY)

# 상황 태그 정의 {태그: (키워드들, 기준 total)}
TAG_DEF = {
    "#혼밥추천":    (["혼밥","혼자","1인"],       30),
    "#데이트추천":  (["데이트","커플","분위기"],   30),
    "#가족추천":    (["가족","아이동반","키즈"],   20),
    "#가성비맛집":  (["가성비","저렴","착한가격"], 40),
    "#분위기좋음":  (["분위기","감성","인테리어"], 30),
    "#주차가능":    (["주차"],                     20),
    "#재방문율높음":(["또왔어요","재방문","단골"], 15),
}


def _clean(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&[a-zA-Z]+;", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _blog_total(name: str, keyword: str) -> int:
    """[식당명 키워드] 블로그 검색 total 수 반환."""
    try:
        q   = parse.quote(f"{name} {keyword}")
        url = f"https://openapi.naver.com/v1/search/blog.json?query={q}&display=1&start=1&sort=sim"
        res = requests.get(url, headers=_nv, timeout=5)
        if res.status_code == 200:
            return int(res.json().get("total", 0))
    except Exception:
        pass
    return 0


def _blog_descriptions(name: str, max_posts: int = 2) -> str:
    """블로그 후기 발췌본 합산 텍스트 반환."""
    combined = ""
    for suffix in ["후기", "리뷰", "맛집"]:
        if len(combined) > 1200:
            break
        try:
            q   = parse.quote(f"{name} {suffix}")
            url = f"https://openapi.naver.com/v1/search/blog.json?query={q}&display={max_posts}&start=1&sort=sim"
            res = requests.get(url, headers=_nv, timeout=6)
            if res.status_code != 200:
                continue
            for item in res.json().get("items", []):
                desc = _clean(item.get("description", ""))
                if desc:
                    combined += desc + " "
        except Exception:
            continue
    return combined.strip()


def _analyze_one(name: str, user_keywords: list[str]) -> dict:
    """
    식당 하나에 대해:
    1. 블로그 total 기반 상황 태그 생성
    2. 블로그 본문 AI 요약
    """
    # 1. 상황 태그 — 사용자 키워드 관련 태그 우선 검사
    tags       = []
    tag_scores = {}

    # 사용자가 요청한 키워드 관련 태그 우선 검사
    priority_tags = {}
    other_tags    = {}
    for tag, (kws, threshold) in TAG_DEF.items():
        if any(uk in tag or any(uk in kw for kw in kws) for uk in user_keywords):
            priority_tags[tag] = (kws, threshold)
        else:
            other_tags[tag] = (kws, threshold)

    for tag, (kws, threshold) in {**priority_tags, **other_tags}.items():
        best = 0
        for kw in kws[:2]:
            total = _blog_total(name, kw)
            best  = max(best, total)
            if best >= threshold:
                break
        tag_scores[tag] = best
        if best >= threshold:
            tags.append(tag)

    # 2. 블로그 본문 AI 요약
    blog_summary = ""
    try:
        text = _blog_descriptions(name, max_posts=2)
        if text:
            prompt = f"""다음은 "{name}" 식당 블로그 후기입니다.
핵심 특징을 1~2문장으로 요약하세요. 순수 텍스트만, HTML 금지.

후기: {text[:1000]}"""
            res = _oai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}],
                temperature=0.2, max_tokens=150,
            )
            blog_summary = re.sub(r"<[^>]+>","",res.choices[0].message.content.strip())
    except Exception:
        pass

    return {
        "situation_tags": tags,
        "tag_scores":     tag_scores,
        "blog_summary":   blog_summary,
    }


def analyze_all(
    restaurants: list[dict],
    user_keywords: list[str],
    max_workers: int = 5,
) -> dict[str, dict]:
    """
    후보 식당 전체를 병렬로 블로그 분석.
    Returns: {"식당명": {"situation_tags":[], "blog_summary":""}}
    """
    results = {}

    def _process(r):
        name = str(r.get("name","")).strip()
        if not name:
            return ("", {})
        try:
            return (name, _analyze_one(name, user_keywords))
        except Exception:
            return (name, {"situation_tags":[], "tag_scores":{}, "blog_summary":""})

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_process, r): r for r in restaurants}
        for f in as_completed(futures):
            try:
                name, data = f.result(timeout=20)
                if name:
                    results[name] = data
            except Exception:
                pass

    return results
