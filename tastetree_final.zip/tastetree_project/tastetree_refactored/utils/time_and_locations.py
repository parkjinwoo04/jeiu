import os
import sys
import urllib.request
import urllib.error
import json
# 키워드 URL 검색용으로 변환
from urllib import parse

client_id = "CLIENT_ID"
client_secret = "CLIENT_SECRET"


def get_geocode(query: str):
    """
    주소 문자열을 위도/경도 좌표로 변환한다.
    - API 실패, 빈 응답, 주소 없음, None 모두 방어 처리
    - 실패 시 None 반환 (예외를 외부로 전파하지 않음)
    """
    if not query or str(query).strip() in ("", "주소 정보 없음", "없음"):
        return None

    try:
        url = f"https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode?query={parse.quote(str(query).strip())}"
        request = urllib.request.Request(url)
        request.add_header("X-NCP-APIGW-API-KEY-ID", client_id)
        request.add_header("X-NCP-APIGW-API-KEY", client_secret)

        response = urllib.request.urlopen(request, timeout=5)
        rescode = response.getcode()

        if rescode == 200:
            response_body = response.read()
            result = json.loads(response_body.decode("utf-8"))

            addresses = result.get("addresses", [])
            if not addresses:
                # 주소 검색 결과 없음
                return None

            x = addresses[0].get("x")
            y = addresses[0].get("y")

            if x is None or y is None:
                return None

            return x, y
        else:
            return None

    except urllib.error.URLError:
        return None
    except urllib.error.HTTPError:
        return None
    except (KeyError, IndexError, ValueError, json.JSONDecodeError):
        return None
    except Exception:
        return None


def reverse_geocode(coords: str, orders="admcode", output="json"):
    """
    위경도 좌표를 행정 구역명으로 변환한다.
    실패 시 None 반환 (예외를 외부로 전파하지 않음)
    """
    if not coords:
        return None

    try:
        url = (
            f"https://naveropenapi.apigw.ntruss.com/map-reversegeocode/v2/gc"
            f"?coords={coords}&orders={orders}&output={output}"
        )
        request = urllib.request.Request(url)
        request.add_header("X-NCP-APIGW-API-KEY-ID", client_id)
        request.add_header("X-NCP-APIGW-API-KEY", client_secret)

        response = urllib.request.urlopen(request, timeout=5)
        rescode = response.getcode()

        if rescode == 200:
            response_body = response.read()
            result = json.loads(response_body.decode("utf-8"))

            results = result.get("results", [])
            if not results:
                return None

            region = results[0].get("region", {})
            area1 = region.get("area1", {}).get("name", "")
            area2 = region.get("area2", {}).get("name", "")
            area3 = region.get("area3", {}).get("name", "")

            return area1, area2, area3
        else:
            return None

    except urllib.error.URLError:
        return None
    except urllib.error.HTTPError:
        return None
    except (KeyError, IndexError, ValueError, json.JSONDecodeError):
        return None
    except Exception:
        return None


def map_js(x, y):
    return (
        """
<script type="text/javascript" src="https://openapi.map.naver.com/openapi/v3/maps.js?ncpClientId=0knhtfya6g"></script>
<div id="map" style="width:100%;height:400px;"></div>

<script>
var mapOptions = {
"""
        + f"    center: new naver.maps.LatLng({y}, {x}),"
        + """
    zoom: 10
};

var map = new naver.maps.Map('map', mapOptions);
</script>"""
    )


if __name__ == "__main__":
    coords = "126.9960392,37.3885389"
    print(reverse_geocode(coords))

    query = "서울시 성동구 행당동 168-151 4F"
    result = get_geocode(query)
    if result:
        x, y = result
        print(map_js(x=x, y=y))
    else:
        print("좌표를 가져올 수 없습니다.")
