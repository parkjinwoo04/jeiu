"""
nearby.py
위치 권한 허용 시 카카오 API로 근처 평점 높은 식당 자동 추천.
"""
import requests

KAKAO_REST_API_KEY = ""  # ← 카카오 REST API 키 (kakao_place.py와 동일)

_headers = {"Authorization": f"KakaoAK {KAKAO_REST_API_KEY}"}


def get_nearby_restaurants(
    lat: float,
    lon: float,
    radius: int = 1000,
    size: int = 15,
) -> list[dict]:
    """
    현재 좌표 기준 반경 내 음식점을 카카오 API로 조회.
    거리순 정렬 후 반환.
    """
    try:
        res = requests.get(
            "https://dapi.kakao.com/v2/local/search/category.json",
            headers=_headers,
            params={
                "category_group_code": "FD6",
                "x":      lon,
                "y":      lat,
                "radius": radius,
                "size":   size,
                "sort":   "distance",
            },
            timeout=8,
        )
        if res.status_code != 200:
            return []

        docs = res.json().get("documents", [])
        results = []
        for d in docs:
            cat = d.get("category_name","")
            if ">" in cat:
                cat = cat.split(">")[-1].strip()
            name = d.get("place_name","")
            dist = int(d.get("distance", 0))
            results.append({
                "name":     name,
                "category": cat,
                "address":  d.get("road_address_name","") or d.get("address_name",""),
                "link":     f"https://map.naver.com/v5/search/{requests.utils.quote(name)}",
                "distance": dist,
                "distance_str": f"{dist}m" if dist < 1000 else f"{dist/1000:.1f}km",
                "reason":   f"현재 위치에서 {dist}m 거리에 있는 {cat} 식당입니다.",
                "highlight": f"도보 {dist//80}분 거리",
                "situation_tags": [],
                "blog_summary": "",
                "score": 7.0,
            })
        return results
    except Exception:
        return []
