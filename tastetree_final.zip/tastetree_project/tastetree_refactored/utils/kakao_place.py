"""
kakao_place.py
카카오 API: 식당명 → 주소 보완 (네이버 맵 링크는 별도 생성)
"""
import requests
from urllib import parse as urlparse

KAKAO_REST_API_KEY = ""  # ← 카카오 REST API 키

_headers = {"Authorization": f"KakaoAK {KAKAO_REST_API_KEY}"}


def _naver_map_url(name: str) -> str:
    """식당명으로 네이버 지도 검색 URL 생성."""
    return f"https://map.naver.com/v5/search/{urlparse.quote(name)}"


def get_place_info(name: str, location: str = "") -> dict:
    """카카오로 주소만 가져오고 링크는 네이버 맵으로."""
    try:
        query = f"{location} {name}".strip() if location else name
        res = requests.get(
            "https://dapi.kakao.com/v2/local/search/keyword.json",
            headers=_headers,
            params={"query": query, "category_group_code": "FD6", "size": 1},
            timeout=6,
        )
        if res.status_code != 200:
            return {"address": "", "link": _naver_map_url(name)}
        docs = res.json().get("documents", [])
        if not docs:
            return {"address": "", "link": _naver_map_url(name)}
        d = docs[0]
        addr = d.get("road_address_name","") or d.get("address_name","")
        return {
            "address": addr,
            "link":    _naver_map_url(name),  # 링크는 항상 네이버 맵
        }
    except Exception:
        return {"address": "", "link": _naver_map_url(name)}


def enrich(restaurants: list[dict], location: str = "") -> list[dict]:
    """식당 목록에 주소·네이버맵 링크 보완."""
    for r in restaurants:
        name   = r.get("name","")
        detail = get_place_info(name, location)
        r["address"] = detail.get("address","") or r.get("address_hint","주소 정보 없음")
        r["link"]    = detail.get("link", _naver_map_url(name))
    return restaurants
