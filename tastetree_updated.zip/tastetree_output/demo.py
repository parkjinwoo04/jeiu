import streamlit as st
from streamlit_js_eval import get_geolocation
from audio_recorder_streamlit import audio_recorder
import json
import time, datetime
import pandas as pd
import numpy as np
import random
import re
from openai import OpenAI

from utils.time_and_locations import reverse_geocode, get_geocode, map_js
from utils.clova_speech import get_clova_stt
from utils.openai_agent import (
    get_search_query, get_order_type, get_review,
    ai_evaluate_restaurants, analyze_blog_reviews, build_blog_ai_summary,
)
from utils.naver_search import get_place_info, get_place_info_bulk, collect_blog_reviews

st.set_page_config(
    page_title="Tastetree : AI 기반 맛집 탐색기",
    page_icon="🌳",
    layout="wide",
)

# ──────────────────────────────────────────────────────────────
# 전역 CSS
# ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── 카드 공통 ── */
.tt-card {
    background: #ffffff;
    border-radius: 16px;
    padding: 22px 24px 18px 24px;
    margin-bottom: 14px;
    border: 1px solid #e8edf2;
    box-shadow: 0 2px 10px rgba(0,0,0,0.07);
}
.tt-card-title {
    font-size: 1.15rem;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 4px;
}
.tt-highlight {
    font-size: 0.87rem;
    color: #7048e8;
    font-weight: 600;
    margin-bottom: 8px;
}
.tt-badge {
    display: inline-block;
    background: #f0f4ff;
    color: #3b5bdb;
    border-radius: 20px;
    padding: 2px 10px;
    font-size: 0.78rem;
    font-weight: 600;
    margin-right: 4px;
    margin-bottom: 4px;
}
.tt-badge-score {
    display: inline-block;
    background: #fff4e6;
    color: #e67700;
    border-radius: 20px;
    padding: 2px 10px;
    font-size: 0.78rem;
    font-weight: 700;
    margin-right: 4px;
}
.tt-meta {
    color: #555;
    font-size: 0.88rem;
    line-height: 1.75;
    margin-top: 8px;
}
.tt-reason {
    background: #f8f9ff;
    border-left: 3px solid #7048e8;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px;
    font-size: 0.87rem;
    color: #333;
    line-height: 1.7;
    margin-top: 12px;
}
.tt-blog-summary {
    background: #fffbf0;
    border-left: 3px solid #f59f00;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px;
    font-size: 0.85rem;
    color: #5c4a00;
    line-height: 1.7;
    margin-top: 8px;
}
.tt-blog-tags {
    margin-top: 6px;
}
.tt-blog-tag-item {
    display: inline-block;
    background: #fff9db;
    color: #856404;
    border: 1px solid #ffe066;
    border-radius: 12px;
    padding: 1px 9px;
    font-size: 0.75rem;
    font-weight: 600;
    margin-right: 4px;
    margin-bottom: 3px;
}
.tt-score-bar-wrap {
    margin-top: 10px;
}
.tt-score-label {
    font-size: 0.78rem;
    color: #666;
    margin-bottom: 2px;
}
.tt-divider {
    border: none;
    border-top: 1.5px solid #f0f0f0;
    margin: 18px 0;
}
.tt-header-sub {
    color: #6c757d;
    font-size: 0.92rem;
    margin-top: -10px;
    margin-bottom: 16px;
}
.tt-rank {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #3b5bdb, #7048e8);
    color: white;
    border-radius: 50%;
    width: 30px;
    height: 30px;
    font-weight: 700;
    font-size: 0.9rem;
    margin-right: 8px;
    flex-shrink: 0;
}
.tt-rank-gold   { background: linear-gradient(135deg, #f59f00, #e67700); }
.tt-rank-silver { background: linear-gradient(135deg, #868e96, #495057); }
.tt-rank-bronze { background: linear-gradient(135deg, #a0522d, #7b3f00); }
.tt-star { color: #f59f00; }
.tt-engine-badge {
    display: inline-block;
    background: linear-gradient(90deg, #7048e8, #3b5bdb);
    color: white;
    border-radius: 6px;
    padding: 2px 10px;
    font-size: 0.75rem;
    font-weight: 700;
    margin-left: 8px;
    vertical-align: middle;
}
</style>
""", unsafe_allow_html=True)

# OpenAI 클라이언트 (parse_cmd 전용)
_openai_client = OpenAI(
    api_key="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"
)


# ──────────────────────────────────────────────────────────────
# 사용자 의도 분석
# ──────────────────────────────────────────────────────────────

def _extract_intent(query: str) -> dict:
    companion_kw  = ["혼밥", "혼자", "데이트", "커플", "가족", "친구", "회식", "아이동반", "단체"]
    atmosphere_kw = ["조용한", "감성", "분위기좋은", "오션뷰", "야경", "고급", "럭셔리", "뷰맛집", "로맨틱"]
    amenity_kw    = ["주차", "단체석", "예약", "룸", "반려동물", "애견동반", "노키즈존"]
    price_kw      = ["가성비", "저렴", "합리적", "고급", "프리미엄", "비싼"]
    extra_kw      = ["현지인", "웨이팅적음", "24시간", "늦게까지", "심야", "웨이팅없는"]

    def _find(kw_list):
        return [kw for kw in kw_list if kw in query]

    return {
        "companion":  _find(companion_kw),
        "atmosphere": _find(atmosphere_kw),
        "amenity":    _find(amenity_kw),
        "price":      _find(price_kw),
        "extra":      _find(extra_kw),
    }


def _intent_summary(intent: dict) -> str:
    parts = []
    if intent.get("companion"):  parts.append("동행: " + ", ".join(intent["companion"]))
    if intent.get("atmosphere"): parts.append("분위기: " + ", ".join(intent["atmosphere"]))
    if intent.get("amenity"):    parts.append("편의: " + ", ".join(intent["amenity"]))
    if intent.get("price"):      parts.append("가격: " + ", ".join(intent["price"]))
    if intent.get("extra"):      parts.append("조건: " + ", ".join(intent["extra"]))
    return " | ".join(parts) if parts else ""


# ──────────────────────────────────────────────────────────────
# parse_cmd — 기존 함수 시그니처 유지
# ──────────────────────────────────────────────────────────────

def parse_cmd(query: str, cur_loc: str = "") -> dict:
    intent = _extract_intent(query)
    intent_hint = _intent_summary(intent)

    prompt = f"""사용자의 요청문에서 아래 세 가지 정보를 추출하여 JSON 한 줄로만 출력하세요.
반드시 키는 "time", "loc", "pref" 세 개를 포함해야 합니다.
찾을 수 없는 항목은 "없음"으로 채우세요.

[추출 규칙]
- "time": 식사 시간대. "아침" / "점심" / "저녁" / "없음" 중 하나.
- "loc": 방문할 지역명.
  * 시·도 + 구·동이 모두 명시된 경우 그대로 사용하세요.
  * 구·동만 있고 시·도가 없는 경우, 현재 위치({cur_loc or '알 수 없음'})의 시·도를 앞에 붙여 완성하세요.
  * 지역 정보가 전혀 없으면 현재 위치({cur_loc or '알 수 없음'})를 그대로 사용하세요.
- "pref": 음식 종류, 분위기, 인원 등 요구사항 키워드. 없으면 "맛집".
  * 아래 의도 정보도 pref에 자연스럽게 포함시키세요: {intent_hint if intent_hint else '없음'}

[출력 예시]
{{"time": "점심", "loc": "부산 해운대", "pref": "혼밥 국밥 가성비"}}

[사용자 입력]
"{query}"
"""
    try:
        response = _openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content.strip())
        for key in ("time", "loc", "pref"):
            if key not in result:
                result[key] = "없음"
        return result
    except Exception:
        return {"time": "없음", "loc": cur_loc or "없음", "pref": "맛집"}


# ──────────────────────────────────────────────────────────────
# 헬퍼 함수 — 기존 유지
# ──────────────────────────────────────────────────────────────

def _build_naver_map_url(title: str, raw_link: str) -> str:
    if raw_link and "map.naver.com" in raw_link:
        return raw_link
    match = re.search(r"place[/=](\d+)", raw_link or "")
    if match:
        return f"https://map.naver.com/v5/entry/place/{match.group(1)}"
    from urllib.parse import quote
    return f"https://map.naver.com/v5/search/{quote(title)}"


def _generate_star_rating(category: str) -> float:
    seed = sum(ord(c) for c in (category or "식당"))
    rng = random.Random(seed)
    return round(rng.uniform(3.5, 4.8), 1)


def _safe_str(val, default="정보 없음") -> str:
    if val is None:
        return default
    s = str(val).strip()
    return s if s else default


# ──────────────────────────────────────────────────────────────
# 지도 렌더링 — 방어 코드 포함
# ──────────────────────────────────────────────────────────────

def _render_map(addr: str, col):
    with col.expander(f"🗺️ 지도 보기  |  📌 {addr}", expanded=False):
        st.markdown(f"**📌 식당 주소:** {addr}")
        st.markdown("---")
        try:
            geocode_result = get_geocode(addr)
            if geocode_result is None:
                st.info("위치 정보를 불러오지 못했습니다.")
                return
            x, y = geocode_result
            if x is None or y is None:
                st.info("위치 정보를 불러오지 못했습니다.")
                return
            df_geocode = pd.DataFrame([[float(y), float(x)]], columns=["lat", "lon"])
            st.map(df_geocode)
        except Exception:
            st.info("위치 정보를 불러오지 못했습니다.")


# ──────────────────────────────────────────────────────────────
# 점수 바
# ──────────────────────────────────────────────────────────────

def _score_bar(label: str, score: float, col):
    clamped = max(0.0, min(10.0, score))
    col.markdown(
        f'<div class="tt-score-label">{label} <strong>{clamped:.1f}</strong>/10</div>',
        unsafe_allow_html=True,
    )
    col.progress(int(clamped * 10))


def _rank_class(rank: int) -> str:
    return {1: "tt-rank tt-rank-gold", 2: "tt-rank tt-rank-silver", 3: "tt-rank tt-rank-bronze"}.get(rank, "tt-rank")


# ──────────────────────────────────────────────────────────────
# [신규] 블로그 분석 태그 렌더링 헬퍼
# ──────────────────────────────────────────────────────────────

_BLOG_TAG_ICONS = {
    "분위기": "🌸",
    "맛평가": "🍴",
    "가성비": "💰",
    "혼밥":   "🧑",
    "데이트": "💑",
    "가족방문": "👨‍👩‍👧",
    "주차":   "🚗",
    "재방문의사": "🔁",
}

_BLOG_TAG_GOOD = {"적합", "가능", "높음", "좋음", "매우좋음", "조용함", "감성적", "가족적", "활기참"}
_BLOG_TAG_BAD  = {"부적합", "불가", "낮음", "나쁨"}


def _render_blog_analysis_tags(blog_analysis: dict) -> str:
    """블로그 분석 결과를 인라인 태그 HTML 문자열로 반환한다."""
    if not blog_analysis:
        return ""
    tags_html = ""
    for key, icon in _BLOG_TAG_ICONS.items():
        val = blog_analysis.get(key, "모름")
        if val == "모름":
            continue
        label = f"{icon} {key}: {val}"
        tags_html += f'<span class="tt-blog-tag-item">{label}</span>'
    return tags_html


# ──────────────────────────────────────────────────────────────
# AI 추천 카드 렌더링 (블로그 분석 포함)
# ──────────────────────────────────────────────────────────────

def _render_ai_result_card(col, rank: int, evaluated: dict, intent: dict):
    """
    AI가 평가·선정한 식당 1개를 카드 UI로 렌더링한다.
    HTML 태그가 사용자 화면에 노출되지 않도록 st.markdown(unsafe_allow_html=True)로만 렌더링.
    """
    name         = _safe_str(evaluated.get("title"),    "이름 없음")
    addr         = _safe_str(evaluated.get("address"),  "주소 정보 없음")
    cat          = _safe_str(evaluated.get("category"), "카테고리 정보 없음")
    link         = evaluated.get("link", "")
    reason       = evaluated.get("reason",    "추천 근거 없음")
    highlight    = evaluated.get("highlight", "")
    scores       = evaluated.get("scores", {})
    blog_analysis = evaluated.get("blog_analysis")   # dict or None
    blog_summary  = evaluated.get("blog_summary", "")  # str

    overall        = scores.get("overall",        5.0)
    companion_fit  = scores.get("companion_fit",  5.0)
    price_fit      = scores.get("price_fit",      5.0)
    amenity_fit    = scores.get("amenity_fit",    5.0)
    atmosphere_fit = scores.get("atmosphere_fit", 5.0)

    safe_url = _build_naver_map_url(name, link)

    # 의도 배지
    badges = ""
    for kw in (intent.get("companion", []) + intent.get("atmosphere", []) +
               intent.get("amenity", []) + intent.get("price", []) + intent.get("extra", [])):
        badges += f'<span class="tt-badge">{kw}</span>'

    # 종합 점수 별점 변환 (10점 → 5점)
    star_val = overall / 2
    filled   = int(round(star_val))
    stars    = "★" * filled + "☆" * (5 - filled)

    rank_cls = _rank_class(rank)

    # 블로그 분석 태그 HTML
    blog_tags_html = _render_blog_analysis_tags(blog_analysis) if blog_analysis else ""

    # ── 카드 HTML 구성 (unsafe_allow_html=True로만 렌더링) ──
    highlight_block = f'<div class="tt-highlight">✨ {highlight}</div>' if highlight else ""
    badges_block    = f'<div style="margin-top:4px;">{badges}</div>' if badges else ""
    blog_tags_block = f'<div class="tt-blog-tags">{blog_tags_html}</div>' if blog_tags_html else ""
    blog_sum_block  = (
        f'<div class="tt-blog-summary">⭐ AI 분석 요약<br>{blog_summary}</div>'
        if blog_summary else ""
    )

    card_html = f"""
<div class="tt-card">
  <div style="display:flex; align-items:flex-start; gap:4px;">
    <span class="{rank_cls}">{rank}</span>
    <div style="flex:1;">
      <div class="tt-card-title">{name}
        <span class="tt-engine-badge">AI 선정</span>
      </div>
      {highlight_block}
      {badges_block}
      <div class="tt-meta">
        <span class="tt-star">{stars}</span>&nbsp;
        <strong>{overall:.1f}</strong>/10 종합점수<br>
        🍽️ {cat}<br>
        📍 {addr}
      </div>
      {blog_tags_block}
    </div>
  </div>
  <div class="tt-reason">💡 {reason}</div>
  {blog_sum_block}
</div>
"""
    col.markdown(card_html, unsafe_allow_html=True)
    col.markdown(f"[🗺️ 네이버 지도에서 보기]({safe_url})")

    # 세부 점수 progress bar
    with col.expander("📊 조건별 적합도 점수", expanded=False):
        score_col1, score_col2 = st.columns(2)

        active_scores = []
        if intent.get("companion"):  active_scores.append(("동행 적합도",    companion_fit))
        if intent.get("price"):      active_scores.append(("가격 적합도",    price_fit))
        if intent.get("amenity"):    active_scores.append(("편의시설 적합도", amenity_fit))
        if intent.get("atmosphere"): active_scores.append(("분위기 적합도",  atmosphere_fit))

        if not active_scores:
            active_scores = [
                ("동행 적합도",     companion_fit),
                ("가격 적합도",     price_fit),
                ("편의시설 적합도", amenity_fit),
                ("분위기 적합도",   atmosphere_fit),
            ]

        for i, (label, score) in enumerate(active_scores):
            target_col = score_col1 if i % 2 == 0 else score_col2
            _score_bar(label, score, target_col)

    # 지도
    _render_map(addr, col)


# ──────────────────────────────────────────────────────────────
# 기존 호환 카드 렌더링 (시그니처 유지)
# ──────────────────────────────────────────────────────────────

def _render_result_card(col, rank: int, name: str, url: str, addr: str,
                        cat: str, pt: float, query: str, intent: dict):
    safe_name = _safe_str(name, "이름 없음")
    safe_addr = _safe_str(addr, "주소 정보 없음")
    safe_cat  = _safe_str(cat,  "카테고리 정보 없음")
    safe_pt   = pt if isinstance(pt, (int, float)) else 0.0
    safe_url  = url if url else f"https://map.naver.com/v5/search/{safe_name}"

    badges = ""
    for kw in (intent.get("companion", []) + intent.get("atmosphere", []) +
               intent.get("amenity", []) + intent.get("extra", [])):
        badges += f'<span class="tt-badge">{kw}</span>'

    star_filled = int(round(safe_pt))
    star_str = "★" * star_filled + "☆" * (5 - star_filled)
    badges_block = f'<div style="margin-top:6px;">{badges}</div>' if badges else ""

    col.markdown(f"""
<div class="tt-card">
  <div class="tt-card-title">
    <span class="tt-rank">{rank}</span>{safe_name}
  </div>
  {badges_block}
  <div class="tt-meta">
    <span class="tt-star">{star_str}</span>
    &nbsp;<strong>{safe_pt}</strong> / 5.0<br>
    🍽️ {safe_cat}<br>
    📍 {safe_addr}
  </div>
</div>
""", unsafe_allow_html=True)

    col.markdown(f"[🗺️ 네이버 지도에서 보기]({safe_url})")
    _render_map(safe_addr, col)

    intent_context = _intent_summary(intent)
    review_context = (
        f"식당명: {safe_name}\n카테고리: {safe_cat}\n위치: {safe_addr}\n평점: {safe_pt}/5.0\n"
        + (f"방문 목적 및 조건: {intent_context}\n" if intent_context else "")
        + "이 식당을 방문한 고객들의 반응을 바탕으로 자연스러운 방문 평을 작성해주세요."
    )
    with col:
        with st.spinner(f"{safe_name} 리뷰 생성중…"):
            try:
                review_summary = get_review(review_context)
            except Exception:
                review_summary = "리뷰 정보를 불러올 수 없습니다."
    with col.expander("💬 주요 리뷰 요약", expanded=True):
        st.markdown(review_summary if review_summary else "리뷰 정보 없음")


# ──────────────────────────────────────────────────────────────
# [신규] AI 추천 엔진 실행 파이프라인 (블로그 후기 분석 통합)
# ──────────────────────────────────────────────────────────────

def _run_ai_recommendation_engine(
    parsed_cmd: dict,
    intent: dict,
    query: str,
    debug: bool,
) -> list[dict] | None:
    """
    1. 다중 검색어로 10~20개 후보 수집 (get_place_info_bulk)
    2. 카테고리 필터링 (get_order_type)
    3. 블로그 후기 수집 및 AI 분석 (collect_blog_reviews + analyze_blog_reviews)
       → 실패 시 기존 로직으로 자동 fallback
    4. AI 조건 평가 + Top 5 선정 (ai_evaluate_restaurants, 블로그 분석 반영)
    5. 결과 list[dict] 반환. 실패 시 None 반환.
    """
    loc  = parsed_cmd.get("loc",  "")
    pref = parsed_cmd.get("pref", "맛집")

    # ── STEP 1: 다중 검색어 생성 ─────────────────────────────
    with st.spinner("🔍 AI 검색어 생성 중…"):
        try:
            search_query = get_search_query(loc=loc, pref=pref)
            search_query["tool"] = "네이버지도"
        except Exception:
            search_query = {"tool": "네이버지도", "query": [f"{loc} {pref}", f"{loc} 맛집"]}

    if debug:
        with st.expander("① 생성된 검색어", expanded=True):
            st.write(search_query["query"])

    # ── STEP 2: 벌크 수집 (10~20개) ──────────────────────────
    with st.spinner(f"🌐 네이버 지도에서 후보 식당 수집 중… (검색어 {len(search_query['query'])}개)"):
        raw_candidates = get_place_info_bulk(
            queries=search_query["query"],
            display_per_query=5,
        )

    if not raw_candidates:
        st.warning("검색 결과를 찾을 수 없습니다. 다른 요청으로 시도해보세요.")
        return None

    if debug:
        with st.expander(f"② 수집된 후보 ({len(raw_candidates)}개)", expanded=False):
            df_c = pd.DataFrame(raw_candidates)
            st.dataframe(df_c[[c for c in ["title", "category", "address", "description"] if c in df_c.columns]])

    # ── STEP 3: 카테고리 필터링 ──────────────────────────────
    with st.spinner("🗂️ 카테고리 정제 중…"):
        try:
            menu_analysis    = get_order_type(instruction=query)
            target_to_remove = menu_analysis.get("targets", [])
        except Exception:
            target_to_remove = []

    filtered = [
        r for r in raw_candidates
        if not any(
            target in str(r.get("category", ""))
            for target in target_to_remove
        )
    ]
    if not filtered:
        filtered = raw_candidates

    if debug:
        with st.expander(f"③ 카테고리 정제 후 ({len(filtered)}개)", expanded=False):
            st.write(f"제거 대상: {target_to_remove}")
            df_f = pd.DataFrame(filtered)
            st.dataframe(df_f[[c for c in ["title", "category", "address"] if c in df_f.columns]])

    # ── STEP 4: 블로그 후기 수집 및 AI 분석 ──────────────────
    # 최소 10개 확보 보장 (필터 후 부족하면 raw 전체 사용)
    candidates_for_blog = filtered if len(filtered) >= 10 else raw_candidates

    blog_analyses: dict = {}
    blog_collection_ok = False

    try:
        with st.spinner(f"📝 블로그 후기 수집 중… (식당 {len(candidates_for_blog)}개 대상)"):
            raw_blog_data = collect_blog_reviews(
                restaurants=candidates_for_blog,
                max_posts_per_restaurant=2,
            )

        # 블로그 데이터가 1개 이상 수집된 경우만 분석 진행
        collected_count = sum(1 for posts in raw_blog_data.values() if posts)
        if collected_count > 0:
            with st.spinner(f"🤖 블로그 후기 AI 분석 중… ({collected_count}개 식당)"):
                for restaurant_name, posts in raw_blog_data.items():
                    if not posts:
                        continue
                    try:
                        ba = analyze_blog_reviews(restaurant_name, posts)
                        blog_analyses[restaurant_name] = ba
                    except Exception:
                        # 개별 식당 분석 실패 → 해당 식당만 건너뜀 (앱 중단 없음)
                        continue
            blog_collection_ok = bool(blog_analyses)

    except Exception:
        # 블로그 수집 전체 실패 → fallback (기존 로직으로 진행)
        blog_analyses = {}
        blog_collection_ok = False

    if debug:
        with st.expander(f"④ 블로그 후기 분석 결과 ({len(blog_analyses)}개 식당)", expanded=False):
            if blog_collection_ok:
                st.json(blog_analyses)
            else:
                st.info("블로그 수집 실패 — 기존 추천 로직으로 진행합니다.")

    # ── STEP 5: AI 조건 평가 + Top 5 선정 ────────────────────
    user_intent = {**parsed_cmd, **intent}
    n = len(filtered)

    blog_status = f" + 블로그 후기 반영 ({len(blog_analyses)}개)" if blog_collection_ok else ""
    with st.spinner(f"🤖 AI가 {n}개 후보를 분석하여 Top 5 선정 중…{blog_status}"):
        try:
            top5 = ai_evaluate_restaurants(
                restaurants=filtered,
                user_intent=user_intent,
                blog_analyses=blog_analyses if blog_collection_ok else None,
            )
        except Exception as e:
            st.warning(f"AI 평가 중 오류가 발생했습니다: {e}")
            return None

    if debug:
        with st.expander("⑤ AI 평가 원본 결과", expanded=False):
            st.json(top5)

    return top5 if top5 else None


# ──────────────────────────────────────────────────────────────
# 메인
# ──────────────────────────────────────────────────────────────

def main():
    KST = datetime.timezone(datetime.timedelta(hours=9))
    timestamp = datetime.datetime.fromtimestamp(time.time(), tz=KST)
    year, month, day = str(timestamp).split()[0].split("-")
    cur_time_hour = int(str(timestamp).split()[1].split(":")[0])
    if cur_time_hour < 11:
        cur_time = "아침"
    elif cur_time_hour < 17:
        cur_time = "점심"
    else:
        cur_time = "저녁"
    weekday = ["월", "화", "수", "목", "금", "토", "일"][timestamp.weekday()]

    try:
        loc = get_geolocation()
        latitude  = loc["coords"]["latitude"]
        longitude = loc["coords"]["longitude"]
        geocode   = f"{longitude},{latitude}"
        admcode   = reverse_geocode(geocode)
    except Exception:
        admcode = ("서울특별시", "성동구", "성수동")

    # ── 헤더 ──────────────────────────────────────────────────
    st.markdown("""
<div style="padding: 8px 0 4px 0;">
  <h1 style="margin:0; font-size:2rem;">
    🌳 Tastetree
    <span style="font-weight:400; color:#555; font-size:1.3rem;">: AI 기반 맛집 탐색기</span>
  </h1>
</div>
""", unsafe_allow_html=True)
    st.markdown('<p class="tt-header-sub">당신의 취향과 상황에 딱 맞는 맛집을 AI가 직접 평가해 추천합니다</p>',
                unsafe_allow_html=True)
    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)

    # ── 상태 정보 ──────────────────────────────────────────────
    info_col1, info_col2, info_col3 = st.columns(3)
    info_col1.metric("📅 날짜", f"{year}.{month}.{day} ({weekday})")
    info_col2.metric("⏰ 시간대", cur_time)

    default_loc_display = (
        f"{admcode[0]} {admcode[1]}" if admcode and len(admcode) >= 2 else "서울특별시 성동구"
    )
    cur_loc         = info_col3.text_input("📍 현재 위치", default_loc_display)
    cur_loc_context = cur_loc

    st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)

    sample_input = "인천에서 혼밥 하기 좋은 맛집"
    debug        = st.checkbox("🔍 AI 추천 과정 단계별 표시", value=False)

    parsed_cmd = None
    query      = sample_input

    # ── 입력 UI ────────────────────────────────────────────────
    with st.container():
        st.markdown("### 🔎 맛집 탐색 요청")
        input_type = st.selectbox("입력 방식", options=["텍스트", "음성"])

        if input_type == "음성":
            col1, col2 = st.columns([1, 3])
            with col1:
                audio_bytes = audio_recorder(
                    text="요청사항 입력",
                    recording_color="#e8b62c",
                    neutral_color="#6aa36f",
                    icon_name="microphone",
                    icon_size="6x",
                )
            if audio_bytes:
                try:
                    stt_result = get_clova_stt(audio_bytes)
                    query = stt_result["text"] if stt_result and "text" in stt_result else ""
                except Exception:
                    query = ""
                if query:
                    col2.subheader(query)
                    with st.spinner("요청사항 분석 중…"):
                        parsed_cmd = parse_cmd(query, cur_loc_context)

        elif input_type == "텍스트":
            query = st.text_input(
                "요청사항 입력", sample_input,
                placeholder="예: 인천 혼밥 국밥 가성비, 강남 데이트 파스타 주차 가능"
            )
            if st.button("🌳 AI 맛집 탐색 시작!", type="primary"):
                with st.spinner("요청사항 분석 중…"):
                    parsed_cmd = parse_cmd(query, cur_loc_context)
                    for kw in ["아침", "점심", "저녁"]:
                        if kw in query and parsed_cmd["time"] == "없음":
                            parsed_cmd["time"] = kw

    # ── 의도 분석 ──────────────────────────────────────────────
    intent = _extract_intent(query)

    if parsed_cmd is not None:
        if parsed_cmd["time"] == "없음":
            parsed_cmd["time"] = cur_time
        if parsed_cmd["loc"] == "없음":
            parsed_cmd["loc"] = cur_loc_context

        intent_text = _intent_summary(intent)
        if intent_text:
            st.markdown(
                f'<div style="color:#7048e8; font-size:0.9rem; margin:8px 0 4px 0;">'
                f'🎯 분석된 조건: {intent_text}</div>',
                unsafe_allow_html=True,
            )

        st.markdown(
            f'<div style="color:#555; font-size:0.85rem; margin-bottom:16px;">'
            f'📍 {parsed_cmd["loc"]} &nbsp;|&nbsp; '
            f'⏰ {parsed_cmd["time"]} &nbsp;|&nbsp; '
            f'🔑 {parsed_cmd["pref"]}</div>',
            unsafe_allow_html=True,
        )

        # ── AI 추천 엔진 실행 ──────────────────────────────────
        st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
        st.markdown("### 🤖 AI 추천 엔진 분석 중")

        top5 = _run_ai_recommendation_engine(
            parsed_cmd=parsed_cmd,
            intent=intent,
            query=query,
            debug=debug,
        )

        # ── 최종 추천 카드 렌더링 ─────────────────────────────
        if top5:
            st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
            st.markdown(
                f"### 🌟 AI 추천 맛집 Top {len(top5)}"
                f'<span class="tt-engine-badge">블로그 후기 + 조건 충족도 평가순</span>',
                unsafe_allow_html=True,
            )

            if intent_text:
                st.markdown(
                    f'<div style="color:#6c757d; font-size:0.85rem; margin-bottom:16px;">'
                    f'총 수집 후보에서 "{intent_text}" 조건을 블로그 후기 분석 및 AI 평가를 통해 선정한 결과입니다.</div>',
                    unsafe_allow_html=True,
                )

            # 상위 3개 → 3열 나란히, 나머지 → 아래
            top3 = top5[:3]
            rest = top5[3:]

            cols3 = st.columns(3)
            for i, (col, ev) in enumerate(zip(cols3, top3)):
                try:
                    _render_ai_result_card(col=col, rank=i + 1, evaluated=ev, intent=intent)
                except Exception:
                    col.warning(f"추천 {i+1} 카드 렌더링 중 오류가 발생했습니다.")

            if rest:
                st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
                st.markdown("#### 🔖 추가 추천")
                rest_cols = st.columns(len(rest))
                for i, (col, ev) in enumerate(zip(rest_cols, rest)):
                    try:
                        _render_ai_result_card(col=col, rank=i + 4, evaluated=ev, intent=intent)
                    except Exception:
                        col.warning(f"추천 {i+4} 카드 렌더링 중 오류가 발생했습니다.")

            st.markdown('<hr class="tt-divider">', unsafe_allow_html=True)
            st.caption("🌳 Tastetree — AI 기반 맛집 탐색기 | Powered by OpenAI, Naver API & Blog Review Analysis")


if __name__ == "__main__":
    main()
