from openai import OpenAI
import json

api_key = "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"
client = OpenAI(api_key=api_key)


# ──────────────────────────────────────────────────────────────
# 기존 함수 — 시그니처·반환 형식 유지
# ──────────────────────────────────────────────────────────────

def get_search_query(loc, pref):
    """
    지역 + 요구사항을 받아 네이버지도 검색어 3~5개를 생성한다.
    반환: {"tool": str, "query": list[str]}
    """
    prompt = f"""당신의 맛집 검색 전문가입니다.
아래 지역과 요구사항을 분석하여 네이버 지도에서 효과적으로 맛집을 찾을 수 있는 한국어 검색어를 5개 생성하세요.

[사용자 의도 분석]
요구사항에서 다음 요소를 파악하여 검색어에 반영하세요:
- 동행 유형: 혼밥, 데이트, 가족, 친구, 회식, 아이동반
- 분위기: 조용한, 감성적인, 분위기좋은, 오션뷰, 야경, 고급스러운
- 편의시설: 주차가능, 단체석, 예약가능, 룸, 반려동물동반
- 추가 조건: 가성비, 현지인맛집, 웨이팅적음, 24시간, 늦게까지영업

[검색어 생성 원칙]
1. 반드시 지역명을 모든 검색어에 포함하세요
2. 각 검색어는 서로 다른 키워드 조합을 사용하세요 (다양성 확보 → 더 많은 후보 수집)
3. 사용자 의도(동행/분위기/편의)가 있으면 해당 키워드를 포함하세요
4. 검색어는 2~4단어로 간결하게 작성하세요

[출력 형식] 반드시 아래 형식으로만 출력하세요:
도구: 네이버지도
검색어: <검색어1>, <검색어2>, <검색어3>, <검색어4>, <검색어5>

지역: {loc}
요구사항: {pref}"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=300,
        )
        result_text = response.choices[0].message.content
        lines = result_text.strip().split("\n")

        tool, query = "네이버지도", []
        for line in lines:
            if "검색어:" in line:
                raw = line.split(":", 1)[1].strip()
                query = [q.strip() for q in raw.split(",") if q.strip()]

        if not query:
            query = [f"{loc} {pref}", f"{loc} 맛집", f"{loc} 맛집 추천",
                     f"{loc} 맛집 혼밥", f"{loc} 가성비 맛집"]

        return {"tool": tool, "query": query}

    except Exception:
        return {"tool": "네이버지도", "query": [f"{loc} {pref}", f"{loc} 맛집"]}


def get_order_type(instruction):
    """요청 문장을 분석해 제거할 카테고리 목록을 반환한다."""
    prompt = f"""아래 <요청>의 목적을 [식사, 음주, 카페] 중 하나로 분류하세요.

출력 형식:
목적: [식사, 음주, 카페] 중 1개

<요청>
{instruction}"""
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=64,
        )
        result = response.choices[0].message.content.split(":")[1].strip()

        type_to_targets = {
            "식사": ["전통 주점 / 포차", "베이커리", "칵테일 / 와인", "일반 주점",
                     "이자카야 / 오뎅 / 꼬치", "카페 / 디저트"],
            "음주": ["베이커리", "브런치 / 버거 / 샌드위치", "카페 / 디저트"],
            "카페": [
                "전통 주점 / 포차", "패밀리 레스토랑", "인도 음식", "기타 양식", "세계음식 기타",
                "프랑스 음식", "탕 / 찌개 / 전골", "다국적 퓨전", "기타 일식", "퓨전 중식",
                "칵테일 / 와인", "기타 중식", "일반 주점", "퓨전 한식", "정통 중식 / 일반 중식",
                "이자카야 / 오뎅 / 꼬치", "남미 음식", "태국 음식", "돈부리 / 일본 카레 / 벤토",
                "라멘 / 소바 / 우동", "다국적 아시아 음식", "이탈리안", "퓨전 양식", "닭 / 오리 요리",
                "퓨전 일식", "기타 한식", "스테이크 / 바베큐", "뷔페", "정통 일식 / 일반 일식",
                "시푸드 요리", "고기 요리", "딤섬 / 만두", "국수 / 면 요리", "베트남 음식",
                "회 / 스시", "까스 요리", "철판 요리", "치킨 / 호프 / 펍", "해산물 요리",
                "한정식 / 백반 / 정통 한식",
            ],
        }
        targets = type_to_targets.get(result, [])
        return {"type": result, "targets": targets}
    except Exception:
        return {"type": "식사", "targets": []}


def get_review(context):
    """
    식당 정보 컨텍스트를 받아 방문 평 요약을 일반 텍스트 3줄로 생성한다.
    """
    prompt = f"""아래 식당 정보를 바탕으로 실제 방문객이 남긴 듯한 자연스러운 리뷰를 정확히 세 줄로 작성하세요.

[작성 규칙]
- 헤더(#), 볼드(**), 이탤릭(*), bullet(-) 등 Markdown 문법을 절대 사용하지 마세요.
- 각 줄은 한 문장으로 끝내고, 줄 사이에 빈 줄 없이 바로 이어 쓰세요.
- 반드시 세 줄만 출력하세요.
- 방문 목적(혼밥, 데이트, 가족 식사, 회식 등)이 명시된 경우 그 관점에서 리뷰를 작성하세요.

{context}"""
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=256,
        )
        return response.choices[0].message.content
    except Exception:
        return "리뷰 정보를 불러올 수 없습니다."


# ──────────────────────────────────────────────────────────────
# [신규] 블로그 후기 AI 분석 — 식당 특성 구조화
# ──────────────────────────────────────────────────────────────

def analyze_blog_reviews(restaurant_name: str, blog_posts: list[dict]) -> dict:
    """
    블로그 후기 텍스트를 AI가 분석하여 식당 특성을 구조화된 JSON으로 반환한다.

    Parameters
    ----------
    restaurant_name : str
        식당명
    blog_posts : list[dict]
        {"title": str, "description": str} 목록 (최대 3개)

    Returns
    -------
    dict
        {
            "분위기": str,         # "조용함" / "활기참" / "감성적" / "가족적" / "모름"
            "맛평가": str,         # "매우좋음" / "좋음" / "보통" / "나쁨" / "모름"
            "가성비": str,         # "좋음" / "보통" / "나쁨" / "모름"
            "혼밥": str,           # "적합" / "보통" / "부적합" / "모름"
            "데이트": str,         # "적합" / "보통" / "부적합" / "모름"
            "가족방문": str,       # "적합" / "보통" / "부적합" / "모름"
            "주차": str,           # "가능" / "불가" / "모름"
            "재방문의사": str,     # "높음" / "보통" / "낮음" / "모름"
            "요약": str            # 한 문장 자연어 요약 (추천 카드에 표시)
        }
        분석 실패 시 모든 값 "모름"으로 채워 반환 (앱 중단 없음)
    """
    _default = {
        "분위기": "모름", "맛평가": "모름", "가성비": "모름",
        "혼밥": "모름", "데이트": "모름", "가족방문": "모름",
        "주차": "모름", "재방문의사": "모름", "요약": ""
    }

    if not blog_posts:
        return _default

    # 블로그 글 텍스트 조합 (최대 3개, 제목+설명)
    blog_text_parts = []
    for i, post in enumerate(blog_posts[:3], 1):
        title = post.get("title", "").strip()
        desc  = post.get("description", "").strip()
        if title or desc:
            blog_text_parts.append(f"[블로그 {i}]\n제목: {title}\n내용: {desc}")

    if not blog_text_parts:
        return _default

    blog_combined = "\n\n".join(blog_text_parts)

    prompt = f"""아래는 "{restaurant_name}" 식당에 대한 네이버 블로그 후기입니다.
후기를 분석하여 식당 특성을 JSON으로만 출력하세요. 다른 텍스트는 절대 출력하지 마세요.

[블로그 후기]
{blog_combined}

[출력 형식] 반드시 아래 JSON 형식 그대로만 출력하세요:
{{
  "분위기": "조용함 또는 활기참 또는 감성적 또는 가족적 또는 모름",
  "맛평가": "매우좋음 또는 좋음 또는 보통 또는 나쁨 또는 모름",
  "가성비": "좋음 또는 보통 또는 나쁨 또는 모름",
  "혼밥": "적합 또는 보통 또는 부적합 또는 모름",
  "데이트": "적합 또는 보통 또는 부적합 또는 모름",
  "가족방문": "적합 또는 보통 또는 부적합 또는 모름",
  "주차": "가능 또는 불가 또는 모름",
  "재방문의사": "높음 또는 보통 또는 낮음 또는 모름",
  "요약": "블로그 후기 기반 한 문장 요약 (30자 이내)"
}}

[분석 규칙]
- 후기에서 명확하게 언급된 내용만 반영하세요.
- 언급이 없거나 판단하기 어려우면 반드시 "모름"으로 표기하세요.
- 요약은 반복적으로 언급된 특징을 자연스러운 문장으로 서술하세요.
- JSON 이외의 텍스트, 설명, 백틱은 절대 출력하지 마세요."""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=400,
        )
        raw = response.choices[0].message.content.strip()

        # JSON 펜스 제거
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip().rstrip("```").strip()

        parsed = json.loads(raw)

        # 필수 키 보완
        for k in _default:
            if k not in parsed or not parsed[k]:
                parsed[k] = _default[k]

        return parsed

    except Exception:
        return _default


def build_blog_ai_summary(blog_analysis: dict, user_intent: dict) -> str:
    """
    블로그 AI 분석 결과를 사용자 의도에 맞는 자연어 추천 문장으로 변환한다.

    Parameters
    ----------
    blog_analysis : dict
        analyze_blog_reviews() 반환값
    user_intent : dict
        _extract_intent() 반환값 (companion, atmosphere, amenity, price, extra 포함)

    Returns
    -------
    str
        추천 카드에 표시할 ⭐ AI 분석 요약 문장. 분석 정보 없으면 빈 문자열.
    """
    if not blog_analysis:
        return ""

    # 의도 기반 강조 포인트 결정
    companion = user_intent.get("companion", [])
    atmosphere = user_intent.get("atmosphere", [])
    amenity = user_intent.get("amenity", [])

    highlights = []

    # 혼밥 의도
    if any(k in companion for k in ["혼밥", "혼자"]):
        val = blog_analysis.get("혼밥", "모름")
        if val == "적합":
            highlights.append("혼자 방문했다는 후기가 많고 가격 부담이 적어 혼밥 사용자에게 적합합니다.")
        elif val == "보통":
            highlights.append("혼밥 방문 후기가 일부 있으며 무난하게 이용 가능한 것으로 보입니다.")

    # 데이트 의도
    if any(k in companion for k in ["데이트", "커플"]):
        val = blog_analysis.get("데이트", "모름")
        분위기 = blog_analysis.get("분위기", "모름")
        if val == "적합":
            atm_desc = f"{'조용하고 감성적인' if 분위기 in ['조용함','감성적'] else '좋은'} 분위기"
            highlights.append(f"블로그 후기에서 {atm_desc}가 반복적으로 언급되어 데이트 목적에 적합한 것으로 판단됩니다.")
        elif val == "보통":
            highlights.append("데이트 방문 후기가 일부 있으나 분위기는 무난한 수준으로 나타납니다.")

    # 가족방문 의도
    if any(k in companion for k in ["가족", "아이동반"]):
        val = blog_analysis.get("가족방문", "모름")
        if val == "적합":
            highlights.append("가족 단위 방문 후기가 많으며 편안한 분위기라는 평이 주를 이룹니다.")

    # 주차 의도
    if "주차" in amenity:
        val = blog_analysis.get("주차", "모름")
        if val == "가능":
            highlights.append("블로그 후기에서 주차 가능 여부가 언급되었습니다.")
        elif val == "불가":
            highlights.append("블로그 후기에서 주차가 어렵다는 언급이 있으니 참고하세요.")

    # 가성비 의도
    price_kw = user_intent.get("price", [])
    if any(k in price_kw for k in ["가성비", "저렴", "합리적"]):
        val = blog_analysis.get("가성비", "모름")
        if val == "좋음":
            highlights.append("가격 대비 만족도가 높다는 후기가 많아 가성비 방문에 적합합니다.")

    # 분위기 의도
    if any(k in atmosphere for k in ["조용한", "감성"]):
        분위기val = blog_analysis.get("분위기", "모름")
        if 분위기val in ["조용함", "감성적"]:
            highlights.append(f"블로그 후기에서 {분위기val} 분위기가 반복적으로 언급됩니다.")

    # 기본 요약 (의도 매칭 없거나 보완)
    base_summary = blog_analysis.get("요약", "")
    if base_summary and not highlights:
        highlights.append(base_summary)

    # 재방문의사 추가
    if blog_analysis.get("재방문의사") == "높음" and len(highlights) < 2:
        highlights.append("방문객 대부분이 재방문 의사를 밝혀 만족도가 높은 식당입니다.")

    return " ".join(highlights) if highlights else base_summary


# ──────────────────────────────────────────────────────────────
# [신규] AI 추천 엔진 — 블로그 분석 반영 + 조건 충족도 평가 + Top 5 선정
# ──────────────────────────────────────────────────────────────

def ai_evaluate_restaurants(
    restaurants: list[dict],
    user_intent: dict,
    blog_analyses: dict[str, dict] | None = None,
) -> list[dict]:
    """
    수집된 식당 후보 목록을 AI가 사용자 조건에 따라 평가하고 Top 5를 반환한다.

    Parameters
    ----------
    restaurants : list[dict]
        각 항목은 {"title", "category", "address", "description", "telephone", "link"} 포함
    user_intent : dict
        parse_cmd 결과 + _extract_intent 결과의 합본
    blog_analyses : dict[str, dict] | None
        식당명 → analyze_blog_reviews() 결과 매핑 (없으면 None → 블로그 정보 미반영)

    Returns
    -------
    list[dict]
        상위 5개 식당. 각 항목:
        {
            "title", "category", "address", "link",
            "scores": {"overall", "companion_fit", "price_fit", "amenity_fit", "atmosphere_fit"},
            "reason", "highlight",
            "blog_analysis": dict,   # 블로그 분석 결과 (없으면 None)
            "blog_summary": str,     # 추천 카드용 AI 분석 요약 문장
        }
    실패 시 입력 restaurants 앞 5개를 기본값으로 래핑하여 반환한다.
    """
    if not restaurants:
        return []

    blog_analyses = blog_analyses or {}

    # ── 식당 목록 → 텍스트 직렬화 ────────────────────────────
    restaurant_lines = []
    for i, r in enumerate(restaurants, 1):
        title       = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
        category    = r.get("category", "")
        address     = r.get("address", "")
        description = r.get("description", "").replace("<b>", "").replace("</b>", "")
        telephone   = r.get("telephone", "")

        parts = [f"[{i}] {title}"]
        if category:    parts.append(f"  카테고리: {category}")
        if address:     parts.append(f"  주소: {address}")
        if description: parts.append(f"  설명: {description}")
        if telephone:   parts.append(f"  전화: {telephone}")

        # 블로그 분석 정보 포함 (있을 경우)
        ba = blog_analyses.get(title, {})
        if ba and any(v != "모름" for v in list(ba.values())[:8]):
            blog_info_parts = []
            for key, label in [("분위기", "분위기"), ("맛평가", "맛"), ("가성비", "가성비"),
                                ("혼밥", "혼밥적합"), ("데이트", "데이트적합"),
                                ("주차", "주차"), ("재방문의사", "재방문")]:
                val = ba.get(key, "모름")
                if val != "모름":
                    blog_info_parts.append(f"{label}:{val}")
            if blog_info_parts:
                parts.append(f"  블로그후기분석: {', '.join(blog_info_parts)}")

        restaurant_lines.append("\n".join(parts))

    restaurants_text = "\n\n".join(restaurant_lines)

    # ── 사용자 의도 직렬화 ────────────────────────────────────
    intent_parts = []
    if user_intent.get("food"):        intent_parts.append(f"음식 종류: {user_intent['food']}")
    if user_intent.get("companion"):   intent_parts.append(f"동행 유형: {', '.join(user_intent['companion']) if isinstance(user_intent['companion'], list) else user_intent['companion']}")
    if user_intent.get("atmosphere"):  intent_parts.append(f"분위기: {', '.join(user_intent['atmosphere']) if isinstance(user_intent['atmosphere'], list) else user_intent['atmosphere']}")
    if user_intent.get("price"):       intent_parts.append(f"가격대: {user_intent['price']}")
    if user_intent.get("amenity"):     intent_parts.append(f"편의시설: {', '.join(user_intent['amenity']) if isinstance(user_intent['amenity'], list) else user_intent['amenity']}")
    if user_intent.get("extra"):       intent_parts.append(f"추가 조건: {', '.join(user_intent['extra']) if isinstance(user_intent['extra'], list) else user_intent['extra']}")
    if user_intent.get("pref"):        intent_parts.append(f"전체 요구사항: {user_intent['pref']}")
    if user_intent.get("loc"):         intent_parts.append(f"지역: {user_intent['loc']}")

    intent_text = "\n".join(intent_parts) if intent_parts else "특별한 조건 없음"

    has_blog_data = bool(blog_analyses)

    # ── AI 평가 프롬프트 ──────────────────────────────────────
    prompt = f"""당신은 맛집 추천 전문가입니다.
아래 [사용자 조건]에 가장 잘 맞는 식당을 [후보 식당 목록]에서 평가하여 상위 5개를 선정하세요.
{"각 식당에는 블로그후기분석 정보가 포함되어 있습니다. 이 정보를 평가에 적극 반영하세요." if has_blog_data else ""}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[사용자 조건]
{intent_text}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[후보 식당 목록] (총 {len(restaurants)}개)
{restaurants_text}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[평가 기준]
각 식당을 다음 4가지 항목으로 0~10점 평가하세요:
1. companion_fit: 동행 유형 적합도
2. price_fit: 가격대 적합도
3. amenity_fit: 편의시설 적합도
4. atmosphere_fit: 분위기 적합도
- overall: 4가지 점수의 가중 평균 (사용자가 요청한 조건에 가중치를 더 줄 것)
{"- 블로그후기분석의 혼밥/데이트/가족방문/주차/가성비/재방문의사 등을 평가 점수에 반영하세요." if has_blog_data else ""}

[추천 근거 작성 규칙]
- reason: 왜 이 식당을 추천하는지 2~3문장으로 구체적으로 서술하세요.
  * Markdown 문법(**, #, -, *) 사용 금지.
- highlight: 이 식당의 핵심 매력을 10자 이내 한 문장으로 요약하세요.

[출력 형식] 반드시 아래 JSON 배열 형식으로만 출력하세요. 다른 텍스트 없이 JSON만 출력하세요.
[
  {{
    "rank": 1,
    "restaurant_index": <후보 목록 번호 1~{len(restaurants)}>,
    "overall": <0~10 소수점 1자리>,
    "companion_fit": <0~10 소수점 1자리>,
    "price_fit": <0~10 소수점 1자리>,
    "amenity_fit": <0~10 소수점 1자리>,
    "atmosphere_fit": <0~10 소수점 1자리>,
    "highlight": "<핵심 한 줄>",
    "reason": "<추천 근거 2~3문장>"
  }},
  ... (총 5개)
]"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=2000,
        )
        raw = response.choices[0].message.content.strip()

        # JSON 펜스 제거
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip().rstrip("```").strip()

        evaluations = json.loads(raw)

        # 후보 데이터 + 평가 결과 + 블로그 분석 병합
        results = []
        for ev in evaluations[:5]:
            idx = int(ev.get("restaurant_index", 1)) - 1
            idx = max(0, min(idx, len(restaurants) - 1))
            r = restaurants[idx]

            title    = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
            category = r.get("category", "카테고리 정보 없음")
            address  = r.get("address", "주소 정보 없음")
            link     = r.get("link", "")

            ba = blog_analyses.get(title)
            blog_summary = build_blog_ai_summary(ba, user_intent) if ba else ""

            results.append({
                "title":    title,
                "category": category if category else "카테고리 정보 없음",
                "address":  address  if address  else "주소 정보 없음",
                "link":     link,
                "scores": {
                    "overall":        float(ev.get("overall",        5.0)),
                    "companion_fit":  float(ev.get("companion_fit",  5.0)),
                    "price_fit":      float(ev.get("price_fit",      5.0)),
                    "amenity_fit":    float(ev.get("amenity_fit",    5.0)),
                    "atmosphere_fit": float(ev.get("atmosphere_fit", 5.0)),
                },
                "reason":       ev.get("reason",    "추천 근거를 생성할 수 없습니다."),
                "highlight":    ev.get("highlight", ""),
                "blog_analysis": ba,
                "blog_summary":  blog_summary,
            })

        return results

    except Exception:
        # 실패 시 앞 5개를 기본값으로 래핑
        fallback = []
        for r in restaurants[:5]:
            title    = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
            category = r.get("category", "카테고리 정보 없음")
            address  = r.get("address", "주소 정보 없음")
            link     = r.get("link", "")
            ba       = blog_analyses.get(title)
            fallback.append({
                "title":    title,
                "category": category if category else "카테고리 정보 없음",
                "address":  address  if address  else "주소 정보 없음",
                "link":     link,
                "scores": {
                    "overall": 5.0, "companion_fit": 5.0,
                    "price_fit": 5.0, "amenity_fit": 5.0, "atmosphere_fit": 5.0,
                },
                "reason":       "AI 평가 중 오류가 발생하여 기본 추천 결과를 제공합니다.",
                "highlight":    "맛집 후보",
                "blog_analysis": ba,
                "blog_summary":  build_blog_ai_summary(ba, user_intent) if ba else "",
            })
        return fallback


if __name__ == "__main__":
    print(get_search_query("인천 서구", "혼밥 국밥"))
    print(get_order_type("저녁에 삼겹살 먹고 싶어요"))
