from openai import OpenAI
import json

api_key = "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"
client = OpenAI(api_key=api_key)


# ──────────────────────────────────────────────────────────────
# 기존 함수 — 시그니처·반환 형식 유지
# ──────────────────────────────────────────────────────────────

def get_search_query(loc, pref):
    """
    지역 + 요구사항을 받아 네이버지도 검색어 3~5개를 생성한다.
    사용자 의도(동행 유형·분위기·편의시설·추가 조건)를 분석하여
    검색 품질을 높인 다양한 검색어를 반환한다.
    반환: {"tool": str, "query": list[str]}
    """
    prompt = f"""당신의 맛집 검색 전문가입니다.
아래 지역과 요구사항을 분석하여 네이버 지도에서 효과적으로 맛집을 찾을 수 있는 한국어 검색어를 5개 생성하세요.

[사용자 의도 분석]
요구사항에서 다음 요소를 파악하여 검색어에 반영하세요:
- 동행 유형: 혼밥, 데이트, 가족, 친구, 회식, 아이동반
- 분위기: 조용한, 감성적인, 분위기좋은, 오션뷰, 야경, 고급스러운
- 편의시설: 주차가능, 단체석, 예약가능, 룸, 반려동물동반
- 추가 조건: 가성비, 현지인맛집, 웨이팅적음, 24시간, 늦게까지영업

[검색어 생성 원칙]
1. 반드시 지역명을 모든 검색어에 포함하세요
2. 각 검색어는 서로 다른 키워드 조합을 사용하세요 (다양성 확보 → 더 많은 후보 수집)
3. 사용자 의도(동행/분위기/편의)가 있으면 해당 키워드를 포함하세요
4. 검색어는 2~4단어로 간결하게 작성하세요

[출력 형식] 반드시 아래 형식으로만 출력하세요:
도구: 네이버지도
검색어: <검색어1>, <검색어2>, <검색어3>, <검색어4>, <검색어5>

지역: {loc}
요구사항: {pref}"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=300,
        )
        result_text = response.choices[0].message.content
        lines = result_text.strip().split("\n")

        tool, query = "네이버지도", []
        for line in lines:
            if "검색어:" in line:
                raw = line.split(":", 1)[1].strip()
                query = [q.strip() for q in raw.split(",") if q.strip()]

        if not query:
            query = [f"{loc} {pref}", f"{loc} 맛집", f"{loc} 맛집 추천",
                     f"{loc} 맛집 혼밥", f"{loc} 가성비 맛집"]

        return {"tool": tool, "query": query}

    except Exception:
        return {"tool": "네이버지도", "query": [f"{loc} {pref}", f"{loc} 맛집"]}


def get_order_type(instruction):
    """요청 문장을 분석해 제거할 카테고리 목록을 반환한다."""
    prompt = f"""아래 <요청>의 목적을 [식사, 음주, 카페] 중 하나로 분류하세요.

출력 형식:
목적: [식사, 음주, 카페] 중 1개

<요청>
{instruction}"""
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=64,
        )
        result = response.choices[0].message.content.split(":")[1].strip()

        type_to_targets = {
            "식사": ["전통 주점 / 포차", "베이커리", "칵테일 / 와인", "일반 주점",
                     "이자카야 / 오뎅 / 꼬치", "카페 / 디저트"],
            "음주": ["베이커리", "브런치 / 버거 / 샌드위치", "카페 / 디저트"],
            "카페": [
                "전통 주점 / 포차", "패밀리 레스토랑", "인도 음식", "기타 양식", "세계음식 기타",
                "프랑스 음식", "탕 / 찌개 / 전골", "다국적 퓨전", "기타 일식", "퓨전 중식",
                "칵테일 / 와인", "기타 중식", "일반 주점", "퓨전 한식", "정통 중식 / 일반 중식",
                "이자카야 / 오뎅 / 꼬치", "남미 음식", "태국 음식", "돈부리 / 일본 카레 / 벤토",
                "라멘 / 소바 / 우동", "다국적 아시아 음식", "이탈리안", "퓨전 양식", "닭 / 오리 요리",
                "퓨전 일식", "기타 한식", "스테이크 / 바베큐", "뷔페", "정통 일식 / 일반 일식",
                "시푸드 요리", "고기 요리", "딤섬 / 만두", "국수 / 면 요리", "베트남 음식",
                "회 / 스시", "까스 요리", "철판 요리", "치킨 / 호프 / 펍", "해산물 요리",
                "한정식 / 백반 / 정통 한식",
            ],
        }
        targets = type_to_targets.get(result, [])
        return {"type": result, "targets": targets}
    except Exception:
        return {"type": "식사", "targets": []}


def get_review(context):
    """
    식당 정보 컨텍스트를 받아 방문 평 요약을 일반 텍스트 3줄로 생성한다.
    사용자 의도(혼밥/데이트/주차/가성비 등)가 있으면 해당 관점에서 리뷰를 작성한다.
    """
    prompt = f"""아래 식당 정보를 바탕으로 실제 방문객이 남긴 듯한 자연스러운 리뷰를 정확히 세 줄로 작성하세요.

[작성 규칙]
- 헤더(#), 볼드(**), 이탤릭(*), bullet(-) 등 Markdown 문법을 절대 사용하지 마세요.
- 각 줄은 한 문장으로 끝내고, 줄 사이에 빈 줄 없이 바로 이어 쓰세요.
- 반드시 세 줄만 출력하세요.
- 방문 목적(혼밥, 데이트, 가족 식사, 회식 등)이 명시된 경우 그 관점에서 리뷰를 작성하세요.

{context}"""
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=256,
        )
        return response.choices[0].message.content
    except Exception:
        return "리뷰 정보를 불러올 수 없습니다."


# ──────────────────────────────────────────────────────────────
# [신규] 블로그 후기 → AI 특성 요약
# ──────────────────────────────────────────────────────────────

def analyze_blog_reviews(restaurant_name: str, blog_posts: list[dict]) -> dict:
    """
    블로그 후기 목록을 OpenAI에 전달하여 식당 특성을 JSON으로 요약받는다.

    Parameters
    ----------
    restaurant_name : str
        식당 이름 (참고용)
    blog_posts : list[dict]
        각 항목: {"title": str, "description": str, "link": str, "bloggername": str}
        search_blog_posts() 반환값

    Returns
    -------
    dict
        {
            "분위기": str,      # 예: "조용함", "활기참", "감성적"
            "맛평가": str,      # 예: "좋음", "보통", "나쁨"
            "가격평가": str,    # 예: "저렴", "합리적", "비쌈"
            "혼밥": str,        # 예: "적합", "보통", "부적합"
            "데이트": str,      # 예: "적합", "보통", "부적합"
            "가족": str,        # 예: "적합", "보통", "부적합"
            "주차": str,        # 예: "가능", "불가", "정보없음"
            "재방문": str,      # 예: "높음", "보통", "낮음"
            "ai_summary": str,  # 블로그 기반 자연어 요약 1~2문장
        }
        블로그 수집 실패 또는 분석 오류 시 기본값 딕셔너리 반환 (fallback)
    """
    # 기본 fallback 반환값
    _fallback = {
        "분위기": "정보없음",
        "맛평가": "정보없음",
        "가격평가": "정보없음",
        "혼밥": "정보없음",
        "데이트": "정보없음",
        "가족": "정보없음",
        "주차": "정보없음",
        "재방문": "정보없음",
        "ai_summary": "",
    }

    if not blog_posts:
        return _fallback

    # 블로그 본문 합산 (너무 길면 잘라냄 — 토큰 절약)
    combined_text = ""
    for i, post in enumerate(blog_posts, 1):
        title       = post.get("title", "")
        description = post.get("description", "")
        excerpt = f"[블로그 {i}] 제목: {title}\n내용: {description}\n"
        combined_text += excerpt
        if len(combined_text) > 2000:   # 2000자 초과 시 중단
            break

    prompt = f"""다음은 식당 "{restaurant_name}"에 대한 네이버 블로그 후기 발췌본입니다.
후기 내용을 분석하여 아래 항목을 JSON 형식으로만 출력하세요. 다른 텍스트 없이 JSON만 출력하세요.

[분석 항목 및 허용 값]
- 분위기: "조용함" / "활기참" / "감성적" / "캐주얼" / "고급스러움" / "정보없음"
- 맛평가: "좋음" / "보통" / "나쁨" / "정보없음"
- 가격평가: "저렴" / "합리적" / "비쌈" / "정보없음"
- 혼밥: "적합" / "보통" / "부적합" / "정보없음"
- 데이트: "적합" / "보통" / "부적합" / "정보없음"
- 가족: "적합" / "보통" / "부적합" / "정보없음"
- 주차: "가능" / "불가" / "정보없음"
- 재방문: "높음" / "보통" / "낮음" / "정보없음"
- ai_summary: 블로그 후기에서 반복적으로 언급된 핵심 특징을 1~2문장으로 요약. 예: "블로그 후기에서 조용한 분위기와 감성적인 인테리어가 반복적으로 언급되어 데이트 목적에 적합한 것으로 판단됩니다."

[블로그 후기]
{combined_text}

[출력 예시]
{{"분위기":"조용함","맛평가":"좋음","가격평가":"합리적","혼밥":"보통","데이트":"적합","가족":"보통","주차":"정보없음","재방문":"높음","ai_summary":"블로그 후기에서 조용한 분위기와 감성적인 인테리어가 반복적으로 언급되어 데이트 목적에 적합한 것으로 판단됩니다."}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=400,
        )
        raw = response.choices[0].message.content.strip()
        # JSON 펜스 제거
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip().rstrip("```").strip()
        result = json.loads(raw)
        # 누락 키 보완
        for k, v in _fallback.items():
            if k not in result:
                result[k] = v
        return result
    except Exception:
        return _fallback


def analyze_blogs_for_restaurants(
    restaurants: list[dict],
    blog_reviews: dict[str, list[dict]],
) -> dict[str, dict]:
    """
    식당 목록 전체에 대해 블로그 분석을 수행한다.

    Parameters
    ----------
    restaurants : list[dict]
        식당 목록 (각 항목에 "title" 필드 포함)
    blog_reviews : dict[str, list[dict]]
        collect_blog_reviews_for_restaurants() 반환값
        {"식당명": [블로그글1, ...], ...}

    Returns
    -------
    dict[str, dict]
        {"식당명": analyze_blog_reviews() 결과, ...}
        블로그가 없거나 실패한 식당은 fallback 값으로 채워짐
    """
    analysis: dict[str, dict] = {}

    for r in restaurants:
        raw_title = str(r.get("title", ""))
        name = raw_title.replace("<b>", "").replace("</b>", "").strip()
        if not name:
            continue
        posts = blog_reviews.get(name, [])
        try:
            analysis[name] = analyze_blog_reviews(restaurant_name=name, blog_posts=posts)
        except Exception:
            analysis[name] = {
                "분위기": "정보없음", "맛평가": "정보없음", "가격평가": "정보없음",
                "혼밥": "정보없음", "데이트": "정보없음", "가족": "정보없음",
                "주차": "정보없음", "재방문": "정보없음", "ai_summary": "",
            }

    return analysis


# ──────────────────────────────────────────────────────────────
# AI 추천 엔진 — 조건 충족도 평가 + Top 5 선정 + 추천 근거 생성
# ──────────────────────────────────────────────────────────────

def ai_evaluate_restaurants(
    restaurants: list[dict],
    user_intent: dict,
    blog_analysis: dict[str, dict] | None = None,
) -> list[dict]:
    """
    수집된 식당 후보 목록을 AI가 사용자 조건에 따라 평가하고 Top 5를 반환한다.
    blog_analysis가 제공되면 블로그 분석 결과도 함께 참고한다.

    Parameters
    ----------
    restaurants : list[dict]
        각 항목은 {"title", "category", "address", "description", "telephone", "link"} 포함
    user_intent : dict
        parse_cmd + _extract_intent 병합 결과
    blog_analysis : dict[str, dict] | None
        {"식당명": analyze_blog_reviews() 결과}. None이면 블로그 분석 없이 평가.

    Returns
    -------
    list[dict]
        상위 5개 식당. 각 항목:
        {
            "title": str,
            "category": str,
            "address": str,
            "link": str,
            "scores": {
                "overall": float,
                "companion_fit": float,
                "price_fit": float,
                "amenity_fit": float,
                "atmosphere_fit": float,
            },
            "reason": str,
            "highlight": str,
            "blog_summary": str,   # 블로그 AI 요약 (없으면 "")
            "blog_tags": dict,     # 블로그 분석 태그 (없으면 {})
        }
    """
    if not restaurants:
        return []

    # ── 식당 목록 텍스트 직렬화 ────────────────────────────────
    restaurant_lines = []
    for i, r in enumerate(restaurants, 1):
        title       = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
        category    = r.get("category", "")
        address     = r.get("address", "")
        description = r.get("description", "").replace("<b>", "").replace("</b>", "")
        telephone   = r.get("telephone", "")

        parts = [f"[{i}] {title}"]
        if category:    parts.append(f"  카테고리: {category}")
        if address:     parts.append(f"  주소: {address}")
        if description: parts.append(f"  설명: {description}")
        if telephone:   parts.append(f"  전화: {telephone}")

        # 블로그 분석 결과 추가
        if blog_analysis and title in blog_analysis:
            ba = blog_analysis[title]
            blog_info_parts = []
            for k in ["분위기", "맛평가", "가격평가", "혼밥", "데이트", "가족", "주차", "재방문"]:
                v = ba.get(k, "정보없음")
                if v and v != "정보없음":
                    blog_info_parts.append(f"{k}={v}")
            if blog_info_parts:
                parts.append(f"  [블로그분석] {', '.join(blog_info_parts)}")
            summary = ba.get("ai_summary", "")
            if summary:
                parts.append(f"  [블로그요약] {summary}")

        restaurant_lines.append("\n".join(parts))

    restaurants_text = "\n\n".join(restaurant_lines)

    # ── 사용자 의도 직렬화 ──────────────────────────────────────
    intent_parts = []
    if user_intent.get("food"):        intent_parts.append(f"음식 종류: {user_intent['food']}")
    if user_intent.get("companion"):   intent_parts.append(f"동행 유형: {', '.join(user_intent['companion']) if isinstance(user_intent['companion'], list) else user_intent['companion']}")
    if user_intent.get("atmosphere"):  intent_parts.append(f"분위기: {', '.join(user_intent['atmosphere']) if isinstance(user_intent['atmosphere'], list) else user_intent['atmosphere']}")
    if user_intent.get("price"):       intent_parts.append(f"가격대: {user_intent['price']}")
    if user_intent.get("amenity"):     intent_parts.append(f"편의시설: {', '.join(user_intent['amenity']) if isinstance(user_intent['amenity'], list) else user_intent['amenity']}")
    if user_intent.get("extra"):       intent_parts.append(f"추가 조건: {', '.join(user_intent['extra']) if isinstance(user_intent['extra'], list) else user_intent['extra']}")
    if user_intent.get("pref"):        intent_parts.append(f"전체 요구사항: {user_intent['pref']}")
    if user_intent.get("loc"):         intent_parts.append(f"지역: {user_intent['loc']}")

    intent_text = "\n".join(intent_parts) if intent_parts else "특별한 조건 없음"
    blog_note = "\n블로그 분석 결과가 [블로그분석] 및 [블로그요약] 형태로 포함되어 있습니다. 이를 반드시 평가에 반영하세요." if blog_analysis else ""

    # ── AI 평가 프롬프트 ─────────────────────────────────────
    prompt = f"""당신은 맛집 추천 전문가입니다.
아래 [사용자 조건]에 가장 잘 맞는 식당을 [후보 식당 목록]에서 평가하여 상위 5개를 선정하세요.{blog_note}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[사용자 조건]
{intent_text}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[후보 식당 목록] (총 {len(restaurants)}개)
{restaurants_text}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[평가 기준]
각 식당을 다음 4가지 항목으로 0~10점 평가하세요:
1. companion_fit: 동행 유형 적합도
2. price_fit: 가격대 적합도
3. amenity_fit: 편의시설 적합도
4. atmosphere_fit: 분위기 적합도
- overall: 4가지 점수의 가중 평균 (사용자 요청 조건에 가중치 부여)

[추천 근거 작성 규칙]
- reason: 왜 이 식당을 추천하는지 2~3문장으로 구체적으로 서술. Markdown 문법 사용 금지.
  블로그 분석 결과가 있으면 "블로그 후기에서 ~가 언급되어" 식으로 반드시 언급하세요.
- highlight: 이 식당의 핵심 매력을 10자 이내 한 문장으로 요약.

[출력 형식] 반드시 아래 JSON 배열 형식으로만 출력하세요.
[
  {{
    "rank": 1,
    "restaurant_index": <후보 목록 번호 1~{len(restaurants)}>,
    "overall": <0~10 소수점 1자리>,
    "companion_fit": <0~10 소수점 1자리>,
    "price_fit": <0~10 소수점 1자리>,
    "amenity_fit": <0~10 소수점 1자리>,
    "atmosphere_fit": <0~10 소수점 1자리>,
    "highlight": "<핵심 한 줄>",
    "reason": "<추천 근거 2~3문장>"
  }},
  ... (총 5개)
]"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=2000,
        )
        raw = response.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip().rstrip("```").strip()
        evaluations = json.loads(raw)

        results = []
        for ev in evaluations[:5]:
            idx = int(ev.get("restaurant_index", 1)) - 1
            idx = max(0, min(idx, len(restaurants) - 1))
            r = restaurants[idx]

            title    = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
            category = r.get("category", "카테고리 정보 없음")
            address  = r.get("address",  "주소 정보 없음")
            link     = r.get("link", "")

            # 블로그 분석 데이터 첨부
            ba = (blog_analysis or {}).get(title, {})
            blog_summary = ba.get("ai_summary", "")
            blog_tags = {k: v for k, v in ba.items() if k != "ai_summary" and v != "정보없음"} if ba else {}

            results.append({
                "title":    title,
                "category": category if category else "카테고리 정보 없음",
                "address":  address  if address  else "주소 정보 없음",
                "link":     link,
                "scores": {
                    "overall":        float(ev.get("overall",        5.0)),
                    "companion_fit":  float(ev.get("companion_fit",  5.0)),
                    "price_fit":      float(ev.get("price_fit",      5.0)),
                    "amenity_fit":    float(ev.get("amenity_fit",    5.0)),
                    "atmosphere_fit": float(ev.get("atmosphere_fit", 5.0)),
                },
                "reason":       ev.get("reason",    "추천 근거를 생성할 수 없습니다."),
                "highlight":    ev.get("highlight", ""),
                "blog_summary": blog_summary,
                "blog_tags":    blog_tags,
            })

        return results

    except Exception:
        # 실패 시 앞 5개 기본값 래핑
        fallback = []
        for r in restaurants[:5]:
            title    = r.get("title", "이름 없음").replace("<b>", "").replace("</b>", "")
            category = r.get("category", "카테고리 정보 없음")
            address  = r.get("address",  "주소 정보 없음")
            link     = r.get("link", "")
            ba = (blog_analysis or {}).get(title, {})
            fallback.append({
                "title":    title,
                "category": category if category else "카테고리 정보 없음",
                "address":  address  if address  else "주소 정보 없음",
                "link":     link,
                "scores": {
                    "overall": 5.0, "companion_fit": 5.0,
                    "price_fit": 5.0, "amenity_fit": 5.0, "atmosphere_fit": 5.0,
                },
                "reason":       "AI 평가 중 오류가 발생하여 기본 추천 결과를 제공합니다.",
                "highlight":    "맛집 후보",
                "blog_summary": ba.get("ai_summary", ""),
                "blog_tags":    {},
            })
        return fallback


if __name__ == "__main__":
    print(get_search_query("인천 서구", "혼밥 국밥"))
    print(get_order_type("저녁에 삼겹살 먹고 싶어요"))
