import sys
import requests
import json
import re
import pandas as pd
from urllib import parse

client_id = "PaS_6JmdJhqcAcNc6XDS"
client_secret = "Se9PEDWXmt"

headers = {
    "X-Naver-Client-Id": client_id,
    "X-Naver-Client-Secret": client_secret,
}


# ──────────────────────────────────────────────────────────────
# 기존 함수 — 시그니처·반환 형식 유지
# ──────────────────────────────────────────────────────────────

def get_place_info(query, display=5, sort="random"):
    """
    네이버 지역 검색 API로 장소 정보를 조회한다.
    실패 시 None 반환 (예외를 외부로 전파하지 않음)
    """
    try:
        encoded_query = parse.quote(str(query))
        url = (
            f"https://openapi.naver.com/v1/search/local.json"
            f"?query={encoded_query}&display={display}&start=1&sort={sort}"
        )
        response = requests.get(url=url, headers=headers, timeout=10)
        rescode = response.status_code
        if rescode == 200:
            items = json.loads(response.text).get("items", [])
            if not items:
                return None
            return pd.DataFrame(items)
        else:
            print(f"Error({rescode}) : " + response.text)
            return None
    except Exception as e:
        print(f"get_place_info 오류: {e}")
        return None


def get_webpage_info(query, display=100):
    """
    네이버 웹 검색 API로 페이지 정보를 조회한다.
    실패 시 None 반환
    """
    try:
        encoded_query = parse.quote(str(query))
        url = (
            f"https://openapi.naver.com/v1/search/webkr.json"
            f"?query={encoded_query}&display={display}&start=1"
        )
        response = requests.get(url=url, headers=headers, timeout=10)
        rescode = response.status_code
        if rescode == 200:
            items = json.loads(response.text).get("items", [])
            if not items:
                return None
            return pd.DataFrame(items)
        else:
            print(f"Error({rescode}) : " + response.text)
            return None
    except Exception as e:
        print(f"get_webpage_info 오류: {e}")
        return None


# ──────────────────────────────────────────────────────────────
# 다중 검색어 벌크 수집 — AI 평가 엔진용
# ──────────────────────────────────────────────────────────────

def get_place_info_bulk(queries: list, display_per_query: int = 5) -> list[dict]:
    """
    여러 검색어로 네이버 지역 API를 호출하여 10~20개 식당 후보를 수집한다.
    중복(title 기준)은 제거하고 dict 리스트로 반환한다.
    """
    seen_titles: set = set()
    results: list[dict] = []

    for query in queries:
        try:
            df = get_place_info(query=query, display=display_per_query, sort="random")
            if df is None or df.empty:
                continue
            for _, row in df.iterrows():
                raw_title = str(row.get("title", "")).replace("<b>", "").replace("</b>", "")
                if raw_title in seen_titles:
                    continue
                seen_titles.add(raw_title)
                results.append(row.to_dict())
        except Exception:
            continue

    return results


# ──────────────────────────────────────────────────────────────
# [신규] 블로그 후기 수집 엔진
# ──────────────────────────────────────────────────────────────

def _clean_html(text: str) -> str:
    """HTML 태그 및 특수문자를 제거하여 순수 텍스트를 반환한다."""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&[a-zA-Z]+;", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def search_blog_posts(restaurant_name: str, max_posts: int = 3) -> list[dict]:
    """
    식당명으로 네이버 블로그 검색을 수행하여 최대 max_posts개의 블로그 글 정보를 반환한다.

    Parameters
    ----------
    restaurant_name : str
        검색할 식당 이름 (HTML 태그 제거된 순수 이름)
    max_posts : int
        수집할 최대 블로그 글 수 (기본 3, 속도 고려)

    Returns
    -------
    list[dict]
        각 항목: {"title": str, "description": str, "link": str, "bloggername": str}
        실패 시 빈 리스트 반환
    """
    if not restaurant_name or restaurant_name.strip() == "":
        return []

    # 검색어 조합: "식당명 후기", "식당명 리뷰", "식당명 맛집" 중 하나로 검색
    search_suffixes = ["후기", "리뷰", "맛집"]
    collected: list[dict] = []

    for suffix in search_suffixes:
        if len(collected) >= max_posts:
            break
        try:
            query = f"{restaurant_name} {suffix}"
            encoded_query = parse.quote(query)
            url = (
                f"https://openapi.naver.com/v1/search/blog.json"
                f"?query={encoded_query}&display=3&start=1&sort=sim"
            )
            response = requests.get(url=url, headers=headers, timeout=8)
            if response.status_code != 200:
                continue
            items = json.loads(response.text).get("items", [])
            for item in items:
                if len(collected) >= max_posts:
                    break
                title       = _clean_html(item.get("title", ""))
                description = _clean_html(item.get("description", ""))
                link        = item.get("link", "")
                bloggername = item.get("bloggername", "")
                # 중복 링크 제거
                if any(b.get("link") == link for b in collected):
                    continue
                if description:  # 내용이 있는 글만 수집
                    collected.append({
                        "title":       title,
                        "description": description,
                        "link":        link,
                        "bloggername": bloggername,
                    })
        except Exception:
            continue

    return collected[:max_posts]


def collect_blog_reviews_for_restaurants(
    restaurants: list[dict],
    max_posts_per_restaurant: int = 2,
) -> dict[str, list[dict]]:
    """
    식당 목록에 대해 블로그 후기를 일괄 수집한다.
    속도를 고려해 식당당 최대 2개의 블로그 글만 수집한다.

    Parameters
    ----------
    restaurants : list[dict]
        각 항목은 {"title": str, ...} 형식의 식당 정보
    max_posts_per_restaurant : int
        식당당 최대 수집 블로그 수 (기본 2)

    Returns
    -------
    dict[str, list[dict]]
        {"식당명": [블로그글1, 블로그글2, ...], ...}
        수집 실패한 식당은 빈 리스트로 포함
    """
    result: dict[str, list[dict]] = {}

    for r in restaurants:
        raw_title = str(r.get("title", ""))
        name = raw_title.replace("<b>", "").replace("</b>", "").strip()
        if not name:
            continue
        try:
            posts = search_blog_posts(name, max_posts=max_posts_per_restaurant)
            result[name] = posts
        except Exception:
            result[name] = []  # 실패 시 빈 리스트 — fallback 처리용

    return result


if __name__ == "__main__":
    result = get_webpage_info("한양대 맛집")
    if result is not None:
        print(result)
    else:
        print("검색 결과가 없습니다.")

    bulk = get_place_info_bulk(["강남 혼밥 맛집", "강남 국밥", "강남 혼자먹기좋은"])
    print(f"벌크 수집 결과: {len(bulk)}개")
    for r in bulk:
        print(f"  - {r.get('title','?')} | {r.get('category','?')}")

    # 블로그 후기 테스트
    test_restaurants = [{"title": "진진"}]
    blog_data = collect_blog_reviews_for_restaurants(test_restaurants, max_posts_per_restaurant=2)
    for name, posts in blog_data.items():
        print(f"\n[{name}] 블로그 후기 {len(posts)}개")
        for p in posts:
            print(f"  - {p['title'][:40]}")
